// outbox.js · 后端不可用时的待同步队列（chrome.storage.local）
// 仅存 bundle（元数据+blocks 文本）与媒体上传状态，不存媒体二进制；
// 后端恢复后由 background 冲刷补推，媒体缺口提示重开页面重存补齐（同 articleId 幂等覆盖）。
// key = bundle.id（articleKey），同一文章重复入队合并为一条（保新）。
(function (root) {
  'use strict';

  var KEY = 'outbox';
  var MAX_ENTRIES = 200; // FIFO 上限：超出时丢弃最旧条目

  function createOutbox(storage) {
    function readAll() {
      return storage.get(KEY).then(function (o) {
        var list = o && o[KEY];
        return Array.isArray(list) ? list : [];
      });
    }
    function writeAll(list) {
      return storage.set((function () { var o = {}; o[KEY] = list; return o; })());
    }
    return {
      readAll: readAll,
      // upsert：同 key 合并（保新），FIFO 截断
      upsert: function (entry) {
        return readAll().then(function (list) {
          var next = list.filter(function (e) { return e.key !== entry.key; });
          next.push(entry);
          if (next.length > MAX_ENTRIES) next = next.slice(next.length - MAX_ENTRIES);
          return writeAll(next);
        });
      },
      remove: function (key) {
        return readAll().then(function (list) {
          return writeAll(list.filter(function (e) { return e.key !== key; }));
        });
      },
      clear: function () {
        return writeAll([]);
      },
    };
  }

  // 入队条目构造：bundle 必含 id；mediaStates 与 bundle.media 下标对应
  //   {status:'ok', url} 已上传成功（url 为终态 /api/media/...，冲刷时直接引用）
  //   {status:'missing', error} 未上传成功（冲刷后仍缺失，保留 warning）
  function entryFromBundle(bundle, mediaStates, error) {
    return {
      key: bundle.id,
      bundle: bundle,
      mediaStates: mediaStates || [],
      attempts: 1,
      lastError: error || '',
      queuedAt: Date.now(),
    };
  }

  // 媒体是否全部落定（无 missing）：决定冲刷后是否可清除条目
  function mediaComplete(entry) {
    var states = (entry && entry.mediaStates) || [];
    for (var i = 0; i < states.length; i++) {
      if (!states[i] || states[i].status === 'missing') return false;
    }
    return true;
  }

  // 缺失媒体描述（用于提示"重开页面重存补齐"）
  function pendingMediaNames(entry) {
    var states = (entry && entry.mediaStates) || [];
    var media = (entry && entry.bundle && entry.bundle.media) || [];
    var names = [];
    for (var i = 0; i < states.length; i++) {
      if (states[i] && states[i].status === 'missing') {
        var m = media[i] || {};
        names.push(m.url || '#' + i);
      }
    }
    return names;
  }

  var api = {
    createOutbox: createOutbox,
    entryFromBundle: entryFromBundle,
    mediaComplete: mediaComplete,
    pendingMediaNames: pendingMediaNames,
    MAX_ENTRIES: MAX_ENTRIES,
  };
  root.DownXOutbox = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
