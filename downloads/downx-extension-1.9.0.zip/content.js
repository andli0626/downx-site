// content.js · 站点探测层：只认识「这个网址是不是 DownX 能存的文章/帖子/公众号图文」
// 注入顺序（manifest content_scripts）：content.js → floating.js
// 边界：UI 一律在 floating.js，本文件不碰 Shadow DOM、不碰 chrome.storage、不碰样式。
(() => {
  if (self.DownXContent) return; // 重复注入幂等：站点知识全帧只需一份

  const ARTICLE = /^\/(?:i|[a-zA-Z0-9_]{1,15})\/article\/\d+\/?$/;
  const STATUS = /^\/[a-zA-Z0-9_]{1,15}\/status\/\d+\/?$/;
  const TWEET_TEXT = '[data-testid^="tweetText_"], [data-testid="tweetText"]';
  const RICH_TEXT = '[data-testid="twitterArticleRichTextView"], [data-testid="longformRichTextComponent"], [data-testid="twitterArticleReadView"]';
  const POST_MEDIA = 'article[data-testid="tweet"] [data-testid="tweetPhoto"] img, article[data-testid="tweet"] video';
  const ON_X = /^https?:\/\/(?:www\.)?(?:x|twitter)\.com\//;

  // 公众号：正文抓取由桌面客户端的采集窗口完成，扩展只负责「这页能不能交出去」+ 递交网址。
  const ON_WECHAT = /^https:\/\/mp\.weixin\.qq\.com\//;
  const WX_SLUG = /^\/s\/([A-Za-z0-9_-]{1,64})\/?$/;
  // 与桌面 task_manager / 服务端 FetchTaskRules 同一套主键口径：长链只留这四参且顺序固定，
  // from/scene/chksm 等跟踪参数一律丢掉，否则同文不同网址会各存一份。
  const WX_QUERY_KEYS = ['__biz', 'mid', 'idx', 'sn'];

  // 可存目标的规范网址；不可存时返回空串。
  // /i/article/<id> 与 /<user>/article/<id> 靠网址即可判定；/<user>/status/<id> 要看正文是否真在页面上，
  // 否则时间线里一条转发也会让入口亮起，点下去存的却是空壳。
  function articleUrl() {
    const path = window.location.pathname;
    if (!ARTICLE.test(path) && !(STATUS.test(path) && document.querySelector(`${TWEET_TEXT}, ${RICH_TEXT}, ${POST_MEDIA}`))) return '';
    return `https://x.com${path.replace(/\/$/, '')}`;
  }

  // 公众号正文字幕：缺 #js_content 的多半是「环境异常 / 需验证」拦截页或合集索引页，
  // 网址看着能存，交出去只会抓到空壳。
  function wechatUrl() {
    if (!ON_WECHAT.test(window.location.href)) return '';
    if (!document.querySelector('#js_content, #js_share_content')) return '';
    const path = window.location.pathname;
    const slug = path.match(WX_SLUG);
    if (slug) return `https://mp.weixin.qq.com/s/${slug[1]}`;
    if (path !== '/s') return '';
    const params = new URLSearchParams(window.location.search);
    const biz = params.get('__biz');
    const sn = params.get('sn');
    const mid = params.get('mid');
    const idx = params.get('idx');
    // 只有 __biz 的网址是账号级入口（合集/话题页），不是某一篇图文——放行会撞主键覆盖同文。
    if (!biz || !(sn || mid || idx)) return '';
    const query = WX_QUERY_KEYS.filter((k) => params.get(k) !== null && params.get(k) !== '')
      .map((k) => `${k}=${params.get(k)}`)
      .join('&');
    return `https://mp.weixin.qq.com/s?${query}`;
  }

  // 当前页面类型：'wechat' 走「仅递交网址」通道，'x' 走页面内提取通道，'' 表示不可存。
  function pageKind() {
    if (ON_WECHAT.test(window.location.href)) return wechatUrl() ? 'wechat' : '';
    return articleUrl() ? 'x' : '';
  }

  // 递交给客户端的网址（不可存时返回空串）。
  function currentTarget() {
    return pageKind() === 'wechat' ? wechatUrl() : articleUrl();
  }

  // probe：本页当前有没有可存目标（开关与客户端在线状态由 floating.js 自己判，它才持有 chrome.storage）
  function probe() {
    if (ON_WECHAT.test(window.location.href)) return !!wechatUrl();
    return ON_X.test(window.location.href) && !!articleUrl();
  }

  self.DownXContent = { probe, currentTarget, pageKind, articleUrl, wechatUrl };
  self.__downxContentTest = { articleUrl, wechatUrl, pageKind, probe };
})();
