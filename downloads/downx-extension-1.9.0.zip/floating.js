// floating.js · DownX 悬浮保存入口（Shadow DOM 内的胶囊钮 + 徽标 + 任务面板）
// 注入顺序（manifest content_scripts）：content.js → extractor.js → md-builder.js → floating.js
// 边界：本文件不含任何 X 站点选择器，「这页能不能存」一律问 self.DownXContent（站点知识单源）；
// 正文提取/Markdown 构建由 background 经 EXTRACT_REQUEST / BUILD_MD 调 extractor.js / md-builder.js。
// 与 background 的消息契约：
//   SAVE_START → {ok,channel:'backend'|'desktop'|'download'|'queued',taskId?,error?}（终态单源）
//   EXPORT_STATE{state:{phase,message}} → tab 推送，仅用于 busy 进度细节（extracting/pushing/uploading/building）
//   task{taskId} → {ok,data:task} · recent → {ok,data:[task]} · retry{taskId} · deleteTask{taskId} · clearFinished → {ok,data}
//   desktop 通道的进度仍靠 task 轮询（与桌面桥接任务系统一致）；offline 仅表示桌面桥接离线（面板不可用），不再阻塞保存。
(function (root) {
  'use strict';

  var HOST_ID = 'downx-floating-host'; // 名字被 tests/ 与 preview-*.cjs 硬编码，勿改
  var POSITION_KEY = 'position';       // 1.6.x 存的是 {left,top}，读出后归一为 {x,y}
  var COLLAPSE_KEY = 'floatCollapsed';
  var ENABLED_KEY = 'enabled';
  var WECHAT_KEY = 'wechatEnabled'; // 站点级开关：缺省即关闭，只有显式 true 才在公众号页亮入口

  var EDGE_PX = 8;
  var THROTTLE_MS = 200;          // 观察器节流：X 时间线 DOM 抖动极频繁，探活复检按窗口合并
  var DRAG_THRESHOLD_PX = 4;      // 位移超过此值算拖动，其后的 click 不得当成「保存」
  var PRESS_TOGGLE_MS = 600;      // 长按主钮 = 胶囊↔圆钮切换（任务面板改由 mini 钮开合）
  var DONE_RESET_MS = 6000;
  var ERROR_RESET_MS = 10000;
  var POLL_FIRST_MS = 1000;
  var POLL_MS = 2000;
  var RECENT_MS = 5000;           // 徽标/在线态的常驻心跳（tests 靠 tick 它验证离线自愈）
  var PANEL_REFRESH_MS = 2000;
  var CIRCLE_PX = 58;             // 收起态圆钮直径：jsdom 量不到宽度时用作钳位兜底

  var TEXT = {
    idle: '保存文章',
    submitting: '正在提取与保存…',
    wechatSubmitting: '交给桌面端 DownX 抓取…',
    submitted: '已提交，等待客户端下载',
    duplicate: '这篇文章已在本地资料库',
    sameUrl: '这篇文章正在保存',
    busyFallback: '正在保存，请稍候',
    okFallback: '保存完成',
    errFallback: '保存失败，请查看任务面板',
    syncedBackend: '已同步到 Web 后端',
    syncedQueued: '后端暂不可达，已加入待同步队列，恢复后自动补推',
    syncedDownload: '已保存到浏览器下载目录',
    offline: '后端与桌面端均离线：本次将保存到浏览器下载目录',
    reload: '插件已更新，请刷新页面后重试',
    connectFail: '保存失败，请重试',
    panelTitle: '下载任务',
    clearFinished: '清空已结束',
    noTask: '暂无下载任务',
    notConnected: '未连接客户端',
    refreshHint: '自动刷新 · ',
    untitled: '文章下载 · 1 篇文章',
    unit: '篇'
  };

  var OFFLINE_ERROR = /failed to fetch|networkerror|network error|load failed|econnrefused|未检测到 downx 客户端/i;
  var ACTIVE_STATUS = { queued: 1, waiting: 1, running: 1, processing: 1 };
  var RETRYABLE_STATUS = { failed: 1, cancelled: 1, partial_failed: 1 };
  var DELETABLE_STATUS = { completed: 1, failed: 1, cancelled: 1, partial_failed: 1 };
  var PROGRESS_STATUS = { running: 1, processing: 1, paused: 1 };
  var STATUS_TEXT = {
    queued: '等待中 · 排队', waiting: '等待中 · 等待执行', running: '下载中 · 正在执行',
    processing: '处理中 · 正在处理', completed: '已完成 · 下载完成', failed: '失败 · 下载出错',
    cancelled: '已取消', paused: '等待中 · 等待继续'
  };
  var STATUS_DOT = {
    queued: 'waiting', waiting: 'waiting', running: 'running', processing: 'running',
    completed: 'completed', failed: 'failed', cancelled: 'cancelled', paused: 'paused'
  };

  // 视觉原则（悬浮入口低干扰）：展开态是「图标 + 动作词」胶囊，收起态是一枚圆钮；
  // 颜色只承担状态语义（深蓝=进行中 / 琥珀=完成 / 朱红=失败 / 灰度=离线），阴影统一中性柔影。
  // 唯一例外是 idle 相：背景随当前下载通道换肤（青蓝=后端直连 / 深藏青=桌面客户端 / 紫=浏览器下载兜底），
  // 让按钮不点也能说明「这次会存到哪」。通道文案与配色映射见 CHANNEL_NAME / channelTheme。
  var CSS = [
    ':host{all:initial;position:fixed;z-index:2147483647;display:block;', // X 自有模态用平台极大值，入口不能被压住
    'font:13px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",system-ui,sans-serif;',
    '--fx-bg1:#1e293b;--fx-bg2:#0f172a;--fx-accent:#fbbf24;--fx-ink:#fbbf24;--fx-ink-ok:#fef3c7;',
    '--fx-busy1:#1d4ed8;--fx-busy2:#1e3a8a;--fx-busy-ink:#dbeafe;--fx-ok1:#b45309;--fx-ok2:#92400e;',
    '--fx-err1:#dc2626;--fx-err2:#991b1b;--fx-err-ink:#fff;',
    '--fx-ch-be1:#0f766e;--fx-ch-be2:#115e59;--fx-ch-dl1:#6d28d9;--fx-ch-dl2:#4c1d95;',
    '--fx-circle:' + CIRCLE_PX + 'px;--fx-pill-h:38px;--fx-mini:28px;--fx-gap:4px;--fx-r:999px}',
    ':host *,:host *::before,:host *::after{box-sizing:border-box}',
    '[hidden]{display:none!important}', // 不能只靠组件自身规则：折叠/状态切换全靠 hidden 属性
    '.fx{position:relative;display:flex;align-items:center;gap:var(--fx-gap);animation:fx-in .18s ease-out}',
    '@keyframes fx-in{from{opacity:0;transform:translateY(4px) scale(.96)}to{opacity:1;transform:none}}',
    /* 主钮：展开=胶囊，收起=圆钮（同一批声明，只有尺寸/圆角不同） */
    '.fx-main{position:relative;display:flex;align-items:center;justify-content:center;gap:7px;',
    'height:var(--fx-pill-h);padding:0 14px;border:0;border-radius:var(--fx-r);',
    'background:linear-gradient(150deg,var(--fx-bg1) 0%,var(--fx-bg2) 100%);color:var(--fx-ink);',
    'cursor:pointer;user-select:none;touch-action:none;',
    'box-shadow:0 10px 24px rgba(15,23,42,.28),0 2px 6px rgba(15,23,42,.12),inset 0 1px 0 rgba(255,255,255,.08);',
    'transition:transform .18s ease,box-shadow .18s ease,background .18s ease,opacity .18s ease}',
    '.fx[data-collapsed="1"] .fx-main{width:var(--fx-circle);height:var(--fx-circle);padding:0;border-radius:50%}',
    '.fx-main::after{content:"";position:absolute;inset:0;border-radius:inherit;border:1px solid rgba(251,191,36,.35);pointer-events:none}',
    '.fx-main:hover,.fx-main:focus-visible{transform:translateY(-1px);',
    'box-shadow:0 12px 28px rgba(15,23,42,.38),0 2px 6px rgba(15,23,42,.12),inset 0 1px 0 rgba(255,255,255,.12)}',
    '.fx-main:focus-visible{outline:none}',
    '.fx-main:focus-visible::after{border-color:var(--fx-accent);box-shadow:0 0 0 3px rgba(251,191,36,.25)}',
    /* 拖拽中：host 提升合成层 + 「抓住」反馈，并压住 hover 上浮造成的抖动 */
    ':host([data-dragging]){will-change:transform}',
    ':host([data-dragging]) .fx-main{cursor:grabbing;transform:scale(.96)!important;',
    'box-shadow:0 12px 28px rgba(15,23,42,.32);transition:transform .08s ease,box-shadow .15s ease}',
    ':host([data-dragging]) .fx-mini{pointer-events:none}',
    /* 状态：只由 data-phase 驱动（className 同步写一份是历史契约，见 render） */
    '.fx-main[data-phase="busy"]{background:linear-gradient(150deg,var(--fx-busy1) 0%,var(--fx-busy2) 100%);',
    'color:var(--fx-busy-ink);cursor:progress;animation:fx-pulse 1.6s ease-in-out infinite}',
    '.fx-main[data-phase="busy"]::after{border-color:rgba(147,197,253,.55)}',
    '@keyframes fx-pulse{0%,100%{box-shadow:0 10px 24px rgba(29,78,216,.32),0 2px 6px rgba(15,23,42,.12)}',
    '50%{box-shadow:0 12px 28px rgba(29,78,216,.55),0 2px 6px rgba(15,23,42,.12)}}',
    '.fx-main[data-phase="ok"]{background:linear-gradient(150deg,var(--fx-ok1) 0%,var(--fx-ok2) 100%);',
    'color:var(--fx-ink-ok);animation:fx-pop .55s cubic-bezier(.34,1.56,.64,1)}',
    '.fx-main[data-phase="ok"]::after{border-color:rgba(254,243,199,.55)}',
    '@keyframes fx-pop{0%{transform:scale(.85)}60%{transform:scale(1.12)}100%{transform:scale(1)}}',
    '.fx-main[data-phase="err"]{background:linear-gradient(150deg,var(--fx-err1) 0%,var(--fx-err2) 100%);',
    'color:var(--fx-err-ink);animation:fx-shake .42s ease}',
    '.fx-main[data-phase="err"]::after{border-color:rgba(254,202,202,.6)}',
    '@keyframes fx-shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-4px)}40%{transform:translateX(4px)}',
    '60%{transform:translateX(-3px)}80%{transform:translateX(2px)}}',
    '.fx-main[data-phase="offline"]{filter:grayscale(.6);opacity:.75}', // 离线=兜底提示而非不可用，保持可点击
    '.fx-main[data-phase="offline"]:hover{transform:translateY(-1px)}',
    /* idle 相的通道换肤：desktop 即默认深藏青，无需规则；探测失败/error 同样留默认色 */
    '.fx-main[data-phase="idle"][data-channel="backend"]{background:linear-gradient(150deg,var(--fx-ch-be1) 0%,var(--fx-ch-be2) 100%)}',
    '.fx-main[data-phase="idle"][data-channel="download"]{background:linear-gradient(150deg,var(--fx-ch-dl1) 0%,var(--fx-ch-dl2) 100%)}',
    /* 图标与文字 */
    '.fx-ico{flex:0 0 auto;display:flex;align-items:center;justify-content:center;width:22px;height:22px}',
    '.fx-ico svg{display:block;width:22px;height:22px}',
    '.fx-spin{animation:fx-rot .8s linear infinite}',
    '@keyframes fx-rot{to{transform:rotate(360deg)}}',
    '.fx-label{white-space:nowrap;font-size:12.5px;font-weight:600;letter-spacing:-.01em}',
    /* mini 钮：任务面板开关；收起态退成玻璃白圆点，默认隐身不抢注意力 */
    '.fx-mini{position:relative;flex:0 0 auto;display:flex;align-items:center;justify-content:center;',
    'width:var(--fx-mini);height:var(--fx-mini);padding:0;border:0;border-radius:50%;',
    'background:rgba(15,23,42,.72);color:var(--fx-accent);cursor:pointer;',
    'box-shadow:0 2px 8px rgba(15,23,42,.18);transition:background .15s ease,opacity .15s ease,transform .15s ease}',
    '.fx-mini svg{display:block;width:15px;height:15px}',
    '.fx-mini:hover{background:var(--fx-bg2);color:#fff}',
    '.fx-mini:active{transform:scale(.94)}',
    '.fx-mini:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(251,191,36,.3)}',
    '.fx[data-collapsed="1"] .fx-mini{background:rgba(255,255,255,.72);color:var(--fx-bg2);',
    'border:1px solid rgba(15,23,42,.08);opacity:0;pointer-events:none}',
    '.fx[data-collapsed="1"]:hover .fx-mini,.fx[data-collapsed="1"]:focus-within .fx-mini{opacity:1;pointer-events:auto}',
    '.fx[data-collapsed="1"] .fx-mini:hover{background:#fff}',
    /* 徽标：展开态贴在 mini 右上（数字说的是任务数，不是按钮状态）；收起态回到圆钮右上 */
    '.fx-badge{position:absolute;top:-5px;right:-5px;min-width:19px;height:19px;padding:0 5px;',
    'background:var(--fx-accent);color:var(--fx-bg2);border-radius:var(--fx-r);border:2px solid #fff;',
    'font:700 11px/19px -apple-system,system-ui,sans-serif;text-align:center;',
    'box-shadow:0 2px 6px rgba(251,191,36,.45);pointer-events:none}',
    '.fx[data-collapsed="1"] .fx-badge{right:calc(var(--fx-mini) + var(--fx-gap) - 5px)}',
    /* 气泡：把失败原因说清楚；靠屏幕哪一侧就往另一侧展开，贴底则朝上 */
    '.fx-notice{position:absolute;top:calc(100% + 10px);left:0;font:12.5px/1.5 -apple-system,system-ui,sans-serif;',
    'color:var(--fx-ink-ok);background:linear-gradient(150deg,var(--fx-bg1),var(--fx-bg2));',
    'border:1px solid rgba(251,191,36,.35);border-radius:10px;padding:9px 12px;width:200px;max-width:60vw;',
    'overflow-wrap:anywhere;pointer-events:none;box-shadow:0 8px 22px rgba(15,23,42,.25)}',
    '.fx-notice[data-side-x="right"]{left:auto;right:calc(var(--fx-mini) + var(--fx-gap))}',
    '.fx[data-collapsed="1"] .fx-notice[data-side-x="right"]{right:0}',
    '.fx-notice[data-side-y="above"]{top:auto;bottom:calc(100% + 10px)}',
    /* 任务面板 */
    '.fx-panel{position:absolute;top:0;right:calc(100% + 10px);width:320px;max-height:min(420px,calc(100vh - 24px));',
    'border-radius:14px;background:#fff;color:#111;box-shadow:0 12px 30px rgba(15,23,42,.18),0 2px 6px rgba(15,23,42,.08);',
    'display:flex;flex-direction:column;overflow:hidden}',
    '.fx-panel[data-side-x="left"]{right:auto;left:calc(100% + 10px)}',
    '.fx-panel[data-side-y="above"]{top:auto;bottom:0}',
    '.fx-panel-head{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;',
    'background:linear-gradient(135deg,#fef3c7 0%,#fde68a 100%);border-bottom:1px solid #fde68a}',
    '.fx-panel-head b{font-size:14px;font-weight:700;color:#78350f}',
    '.fx-panel-count{font-size:11px;font-weight:700;color:var(--fx-ink-ok);background:#92400e;padding:2px 8px;border-radius:var(--fx-r)}',
    '.fx-panel-body{overflow:auto;max-height:300px;padding:8px 12px}',
    '.fx-row{padding:9px 12px;border-radius:10px;background:#fff;border:1px solid #f1f5f6;margin-bottom:6px;',
    'transition:border-color .15s ease,box-shadow .15s ease}',
    '.fx-row:last-child{margin-bottom:0}',
    '.fx-row:hover{border-color:#fde68a;box-shadow:0 2px 8px rgba(180,83,9,.08)}',
    '.fx-row-title{font-weight:600;color:#1e293b;font-size:13px;overflow:hidden;text-overflow:ellipsis;',
    'white-space:nowrap;margin:0 0 4px;letter-spacing:-.01em}',
    '.fx-row-title.none{color:#94a3b8;font-weight:400;font-style:italic}',
    '.fx-row-meta{display:flex;align-items:center;gap:6px;font-size:11.5px;color:#94a3b8;min-width:0}',
    '.fx-row-status{display:flex;align-items:center;gap:4px;font-size:11.5px;color:#64748b;font-weight:500;flex:0 0 auto}',
    '.fx-dot{width:6px;height:6px;border-radius:50%;flex:0 0 auto;border:2px solid transparent}',
    '.fx-dot.waiting{background:#f59e0b;border-color:#fef3c7}',
    '.fx-dot.running{background:#3b82f6;border-color:#dbeafe;animation:fx-blink 1.5s ease-in-out infinite}',
    '.fx-dot.completed{background:#22c55e;border-color:#dcfce7}',
    '.fx-dot.failed,.fx-dot.cancelled{background:#ef4444;border-color:#fee2e2}',
    '.fx-dot.paused{background:#9ca3af;border-color:#f3f4f6}',
    '@keyframes fx-blink{0%,100%{opacity:1}50%{opacity:.4}}',
    '.fx-row-count{white-space:nowrap;color:#94a3b8}',
    '.fx-row-bar{flex:1 1 auto;height:3px;background:#fef3c7;border-radius:2px;overflow:hidden;min-width:24px}',
    '.fx-row-bar .fx-bar{height:100%;background:linear-gradient(90deg,#f59e0b,var(--fx-accent));border-radius:2px;',
    'transition:width .3s ease;background-size:200% 100%;animation:fx-slide 2s linear infinite}',
    '.fx-row-actions{display:flex;gap:4px;flex:0 0 auto;margin-left:auto}',
    '.fx-act{display:inline-flex;align-items:center;gap:3px;font:11px -apple-system,system-ui,sans-serif;font-weight:500;',
    'color:#92400e;background:#fffbeb;border:1px solid #fde68a;border-radius:5px;padding:3px 7px;cursor:pointer;',
    'line-height:1;transition:background .15s ease,border-color .15s ease,color .15s ease,opacity .15s ease}',
    '.fx-act:hover{background:#fef3c7;border-color:var(--fx-accent);color:#78350f}',
    '.fx-act.danger{color:#b91c1c;background:transparent;border-color:transparent;padding:3px 5px}',
    '.fx-act.danger:hover{background:#fef2f2;border-color:transparent;color:#dc2626}',
    '.fx-act svg{flex:0 0 auto;display:block}',
    '.fx-act span{pointer-events:none}',
    '.fx-act:disabled{opacity:.5;cursor:default}',
    '.fx-panel-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 16px;',
    'border-top:1px solid #f1f5f9;background:#fffbeb}',
    '.fx-panel-hint{font-size:11px;color:#94a3b8;pointer-events:none;white-space:nowrap}',
    '.fx-empty{padding:32px 16px;text-align:center;color:#94a3b8;font-size:13px;line-height:1.5}',
    '.fx-empty.offline{color:#b45309}',
    '.fx-empty-ico{font-size:26px;margin-bottom:8px;opacity:.4}',
    '.fx-bar-bg{height:4px;background:#fef3c7;border-radius:2px;margin-top:6px;overflow:hidden}',
    '.fx-bar{height:100%;background:linear-gradient(90deg,#f59e0b,var(--fx-accent));border-radius:2px;',
    'transition:width .3s ease;background-size:200% 100%;animation:fx-slide 2s linear infinite}',
    '@keyframes fx-slide{0%{background-position:200% 0}100%{background-position:-200% 0}}',
    '@media (prefers-reduced-motion:reduce){.fx,.fx-main,.fx-mini,.fx-spin,.fx-dot.running,.fx-bar,',
    '.fx-main[data-phase="busy"],.fx-main[data-phase="ok"],.fx-main[data-phase="err"]{animation:none}}'
  ].join('');

  /* ---------- 纯函数 ---------- */
  function count(v) {
    var n = Number(v);
    return isFinite(n) && n > 0 ? Math.floor(n) : 0;
  }
  // 状态 → 文案单源。label 只放短动作词（胶囊宽度不能被长文案撑破），详情/失败原因进 title 与气泡。
  // idle 相额外携带通道名后缀（仅 title/aria）：换肤背景需要文字可解码，长文案不挤胶囊。
  function phaseText(phase, info) {
    info = info || {};
    if (phase === 'busy') return { label: '保存中', title: info.detail || TEXT.busyFallback };
    if (phase === 'ok') return { label: '已保存', title: info.detail || TEXT.okFallback };
    if (phase === 'err') return { label: '保存失败', title: info.detail || TEXT.errFallback };
    if (phase === 'offline') return { label: '离线兜底', title: TEXT.offline }; // 离线≠不可用：点击走下载目录兜底
    var title = TEXT.idle + (info.channelName ? ' · ' + info.channelName : '');
    return { label: TEXT.idle, title: title }; // 含未知态：回落 idle，不渲染 undefined
  }
  // UI_PROBE 的 channel → 按钮皮肤键（单源）。error/queued/未知一律 default：
  // 探测不确定时不给误导性配色。
  function channelTheme(ch) {
    return ch === 'backend' || ch === 'desktop' || ch === 'download' ? ch : 'default';
  }
  var CHANNEL_NAME = { backend: '后端直连', desktop: '桌面客户端', download: '浏览器下载' };
  function clampPos(x, y, w, h, vw, vh) {
    return {
      x: Math.min(Math.max(x, 0), Math.max(0, vw - w)),
      y: Math.min(Math.max(y, 0), Math.max(0, vh - h))
    };
  }
  // 已存坐标必须两值都是有限数，否则整体回落默认位（半个坐标不采信）。
  // 兼容 1.6.x 的 {left,top}：只认新键会让人群在升级后按钮莫名回到默认位。
  function validPos(state) {
    if (!state) return null;
    var x = Number(state.x !== undefined ? state.x : state.left);
    var y = Number(state.y !== undefined ? state.y : state.top);
    if (!isFinite(x) || !isFinite(y) || x < 0 || y < 0) return null;
    return { x: x, y: y };
  }
  function errorMessage(e) {
    var message = (e && e.message) || '';
    if (/context invalidated|receiving end does not exist/i.test(message)) return TEXT.reload;
    if (isOffline(e)) return TEXT.offline;
    return message || TEXT.connectFail;
  }
  function isOffline(e) {
    return (e && e.code === 'offline') || OFFLINE_ERROR.test((e && e.message) || '');
  }
  function apiFailure(result, fallback) {
    var e = Error((result && result.error) || fallback);
    e.code = result && result.code;
    return e;
  }
  // 徽标：客户端在跑的任务 ∪ 本页已提交未落定的任务（'pending' 表示已提交但还没拿到 taskId）
  function deriveBadge(tasks, activeValues) {
    var ids = {}, n = 0, i;
    tasks = tasks || [];
    for (i = 0; i < tasks.length; i++) {
      if (ACTIVE_STATUS[tasks[i].status] && tasks[i].id && !ids[tasks[i].id]) { ids[tasks[i].id] = 1; n++; }
    }
    activeValues = activeValues || [];
    for (i = 0; i < activeValues.length; i++) {
      if (activeValues[i] === 'pending') n++;
      else if (activeValues[i] && !ids[activeValues[i]]) { ids[activeValues[i]] = 1; n++; }
    }
    return n;
  }
  function itemCount(task) {
    task = task || {};
    if (task.itemCount > 0) return count(task.itemCount);
    if (task.items && task.items.length) return task.items.length;
    return 1;
  }
  function truncateTitle(title, max) {
    var t = String(title == null ? '' : title).trim();
    var limit = max === undefined ? 22 : max;
    return t.length > limit ? t.slice(0, limit) + '…' : t;
  }
  function statusLabel(status) { return STATUS_TEXT[status] || status || '未知'; }
  function statusDot(status) { return STATUS_DOT[status] || 'waiting'; }
  function progressWidth(task) {
    var raw = Number(task && task.progress);
    var w = isFinite(raw) && raw > 0 ? raw : 30; // 进度未知时给个起步值，条子不至于空着
    return Math.max(2, Math.min(w, 95));
  }
  // 面板 HTML：整块 innerHTML 是我们完全拥有的容器，但任务标题来自 X 页面 ⇒ 逐格转义，
  // 一处漏转就是一个可被文章作者控制的注入点（1.6.x 的 title 就是裸插的）。
  function panelHtml(tasks, opts) {
    opts = opts || {};
    var badge = count(opts.badge);
    var rows = (tasks || []).slice(0, 20).map(rowHtml).join('');
    return '<div class="fx-panel-head"><b>' + esc(TEXT.panelTitle) + '</b>' +
      (badge ? '<span class="fx-panel-count">' + esc(badge) + '</span>' : '') + '</div>' +
      '<div class="fx-panel-body">' + (rows || emptyHtml(!!opts.offline)) + '</div>' +
      '<div class="fx-panel-foot"><button type="button" class="fx-act" data-task-action="clearFinished">' +
      esc(TEXT.clearFinished) + '</button><span class="fx-panel-hint" data-el="hint"></span></div>';
  }
  function rowHtml(t) {
    var title = truncateTitle(t && t.title);
    var actions = '';
    if (RETRYABLE_STATUS[t.status]) actions += '<button type="button" class="fx-act" data-task-action="retry" data-task-id="' + esc(t.id) + '" title="重试">' + RETRY_SVG + '<span>重试</span></button>';
    if (DELETABLE_STATUS[t.status]) actions += '<button type="button" class="fx-act danger" data-task-action="delete" data-task-id="' + esc(t.id) + '" title="删除任务">' + TRASH_SVG + '</button>';
    var progress = PROGRESS_STATUS[t.status]
      ? '<div class="fx-row-bar"><div class="fx-bar" style="width:' + progressWidth(t) + '%"></div></div>'
      : '';
    return '<div class="fx-row"><div class="fx-row-title' + (title ? '' : ' none') + '">' +
      esc(title || TEXT.untitled) + '</div><div class="fx-row-meta">' +
      '<div class="fx-row-status"><span class="fx-dot ' + esc(statusDot(t.status)) + '"></span>' +
      '<span>' + esc(statusLabel(t.status)) + '</span></div>' +
      '<span class="fx-row-count">' + esc(itemCount(t)) + ' ' + esc(TEXT.unit) + '</span>' +
      progress +
      (actions ? '<span class="fx-row-actions">' + actions + '</span>' : '') + '</div></div>';
  }
  function emptyHtml(offline) {
    return offline
      ? '<div class="fx-empty offline"><div class="fx-empty-ico">⚠</div>未检测到 DownX 客户端<br>请先打开 DownX 客户端</div>'
      : '<div class="fx-empty"><div class="fx-empty-ico">◎</div>' + esc(TEXT.noTask) + '</div>';
  }
  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var TRASH_SVG = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>';
  var RETRY_SVG = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>';

  // boot 守卫条件（纯函数：锁定「导入期绝不碰 DOM」的形态）。
  // 注意不要求 runtime.onMessage：本扩展没有后台→tab 推送通道，照抄姊妹扩展会让按钮静默不出现。
  function canAutoStart(deps) {
    if (!deps || !deps.doc || !deps.win || !deps.contentApi) return false;
    if (typeof deps.contentApi.probe !== 'function' || typeof deps.contentApi.currentTarget !== 'function') return false;
    var c = deps.chromeApi;
    if (!c || !c.runtime || typeof c.runtime.sendMessage !== 'function') return false;
    if (!c.storage || !c.storage.local || typeof c.storage.local.get !== 'function') return false;
    if (typeof deps.win.setTimeout !== 'function') return false;
    if (typeof deps.win.MutationObserver !== 'function') return false;
    return true;
  }

  // 站点级裁决：扩展默认只认 X 文章。公众号图文的正文要靠桌面端采集窗口抓取，
  // 未显式开启时连入口都不亮（探测层仍会如实报告可存，这里只管「让不让按」）。
  function siteAllowed(contentApi, wechatEnabled) {
    if (wechatEnabled === true) return true;
    try {
      return !(typeof contentApi.pageKind === 'function' && contentApi.pageKind() === 'wechat');
    } catch (e) {
      return true; // 判定层抛错时不擅自拦下页面：挂载后 probe 失败自有静默不显示
    }
  }

  // 真机排查「为什么没按钮」的单源：三种成因各有独立标记，别把站点开关关掉误判成探测失效
  function mountReason(cfg, contentApi) {
    var c = cfg || {};
    if (c[ENABLED_KEY] === false) return 'disabled';
    if (!siteAllowed(contentApi, c[WECHAT_KEY] === true)) return 'wechat-disabled';
    return 'not-probed';
  }

  /* ---------- 控制器（一帧一个） ---------- */
  function Controller(deps, cfg) {
    var self = this;
    var doc = deps.doc, win = deps.win, chromeApi = deps.chromeApi, contentApi = deps.contentApi;
    var host = null, ui = null, observer = null;
    var phase = 'idle', info = null, quiet = false;
    // 位置/收起态只在构造时读一次存储快照；后续 unmount→remount（X 时间线换页很频繁）
    // 必须沿用内存里的最新值，否则会被启动时的旧快照覆盖，按钮「弹回」默认位置。
    var pos = validPos(cfg && cfg[POSITION_KEY]), collapsed = !!(cfg && cfg[COLLAPSE_KEY]);
    var offline = false, dragged = false, panelOpen = false, enabled = !(cfg && cfg[ENABLED_KEY] === false);
    var wechatEnabled = !!(cfg && cfg[WECHAT_KEY] === true);
    var channel = 'default'; // 当前下载通道皮肤键，由 UI_PROBE 心跳刷新
    var tasksCache = [], pollToken = 0;
    var resetTimer = null, pressTimer = null, pollTimer = null, recentTimer = null, panelTimer = null, checkTimer = null;
    var active = {}; // url -> taskId | 'pending'

    this.attached = false;

    function activeValues() {
      var out = [], k;
      for (k in active) if (Object.prototype.hasOwnProperty.call(active, k)) out.push(active[k]);
      return out;
    }
    function forgetTask(taskId) {
      var k;
      for (k in active) if (Object.prototype.hasOwnProperty.call(active, k) && active[k] === taskId) delete active[k];
    }
    function send(type, payload) {
      var msg = { type: type };
      if (payload) for (var k in payload) if (Object.prototype.hasOwnProperty.call(payload, k)) msg[k] = payload[k];
      return Promise.resolve(chromeApi.runtime.sendMessage(msg));
    }

    /* ---------- 几何 ---------- */
    function metrics() {
      // jsdom 与「尚未插入文档」都量到 0；圆钮宽度是既有视觉基线，用它兜底而不是 0
      var w = (ui && (ui.root.offsetWidth || ui.root.getBoundingClientRect().width)) || CIRCLE_PX;
      var h = (ui && (ui.root.offsetHeight || ui.root.getBoundingClientRect().height)) || CIRCLE_PX;
      return { w: w, h: h, vw: win.innerWidth || 0, vh: win.innerHeight || 0 };
    }
    function defaultPos(m) {
      return { x: Math.max(EDGE_PX, m.vw - m.w - EDGE_PX), y: Math.max(EDGE_PX, Math.round((m.vh - m.h) / 2)) };
    }
    // 贴边翻转：气泡和面板都比按钮宽/高得多，靠哪一侧就往另一侧长，否则会被屏幕边缘裁掉
    function placeFlyouts(m) {
      if (!ui) return;
      var toRight = pos.x + m.w / 2 > m.vw / 2;
      ui.notice.setAttribute('data-side-x', toRight ? 'right' : 'left');
      ui.notice.setAttribute('data-side-y', pos.y + m.h + 120 > m.vh ? 'above' : 'below');
      ui.panel.setAttribute('data-side-x', toRight ? 'left' : 'right');
      ui.panel.setAttribute('data-side-y', pos.y + 420 > m.vh ? 'above' : 'below');
    }
    function applyPos() {
      if (!host || !pos) return;
      var m = metrics();
      pos = clampPos(pos.x, pos.y, m.w, m.h, m.vw, m.vh);
      host.style.left = pos.x + 'px';
      host.style.top = pos.y + 'px';
      placeFlyouts(m);
    }

    /* ---------- 渲染 ---------- */
    // SVG 元素的 hidden IDL 属性在部分内核上不反映为内容属性，CSS [hidden] 会漏匹配
    // （姊妹扩展曾因此让四个状态图标叠成一团）；显隐统一走内容属性开关。
    function setHidden(el, hidden) {
      if (hidden) el.setAttribute('hidden', '');
      else el.removeAttribute('hidden');
    }
    function icon(paths, cls) {
      var SVG_NS = 'http://www.w3.org/2000/svg';
      var el = doc.createElementNS(SVG_NS, 'svg');
      el.setAttribute('viewBox', '0 0 24 24');
      el.setAttribute('fill', 'none');
      el.setAttribute('stroke', 'currentColor');
      el.setAttribute('stroke-width', '2.1');
      el.setAttribute('stroke-linecap', 'round');
      el.setAttribute('stroke-linejoin', 'round');
      if (cls) el.setAttribute('class', cls);
      paths.forEach(function (d) {
        var p = doc.createElementNS(SVG_NS, 'path');
        p.setAttribute('d', d);
        el.appendChild(p);
      });
      return el;
    }
    function render() {
      if (!ui) return;
      var chName = phase === 'idle' ? CHANNEL_NAME[channel] : null;
      var t = phaseText(phase, chName ? { channelName: chName } : info);
      ui.main.setAttribute('data-phase', phase);
      ui.main.setAttribute('data-channel', channel);
      ui.main.setAttribute('title', t.title);
      ui.main.setAttribute('aria-label', chName ? t.title : t.label); // idle 连通道一起播报；其余态保持短词
      ui.main.setAttribute('aria-busy', phase === 'busy' ? 'true' : 'false');
      ui.label.textContent = t.label;
      setHidden(ui.label, collapsed); // 收起态只留图标：文字用 hidden 而非仅 CSS，读屏与 Tab 都不该碰到
      setHidden(ui.icons.idle, phase !== 'idle');
      setHidden(ui.icons.busy, phase !== 'busy');
      setHidden(ui.icons.ok, phase !== 'ok');
      setHidden(ui.icons.err, phase !== 'err');
      setHidden(ui.icons.offline, phase !== 'offline');
      ui.root.setAttribute('data-collapsed', collapsed ? '1' : '0');
      ui.mini.setAttribute('aria-label', panelOpen ? '收起任务面板' : '查看任务面板');
      setHidden(ui.icons.panel, panelOpen);
      setHidden(ui.icons.close, !panelOpen);
      var text = (info && info.detail) || t.title;
      ui.notice.textContent = text;
      setHidden(ui.notice, quiet || phase === 'idle' || !text || text === TEXT.idle);
    }
    function setPhase(next, nextInfo, nextQuiet) {
      phase = next;
      info = nextInfo || null;
      quiet = !!nextQuiet;
      if (resetTimer) { win.clearTimeout(resetTimer); resetTimer = null; }
      render();
      var ms = next === 'ok' ? DONE_RESET_MS : (next === 'err' ? ERROR_RESET_MS : 0);
      if (ms) resetTimer = win.setTimeout(function () { resetTimer = null; setPhase('idle'); }, ms);
    }
    function applyOffline(next) {
      if (next === offline) return;
      offline = next;
      if (next) {
        tasksCache = []; // 断连后手上的任务列表已不可信，面板改说离线
        if (phase === 'idle' || phase === 'offline') setPhase('offline', null, true);
      } else if (phase === 'offline') {
        setPhase('idle');
      }
      renderPanel();
    }

    /* ---------- 持久化 ---------- */
    function persist(kv) {
      try {
        var p = chromeApi.storage.local.set(kv);
        if (p && typeof p.catch === 'function') p.catch(function () {});
      } catch (e) { /* 写失败：本次会话内位置/形态仍然生效 */ }
    }
    function persistPos() { var kv = {}; kv[POSITION_KEY] = { x: pos.x, y: pos.y }; persist(kv); }
    function persistCollapsed() { var kv = {}; kv[COLLAPSE_KEY] = collapsed; persist(kv); }

    /* ---------- 任务面板 ---------- */
    function renderPanel() {
      if (!ui) return;
      var badge = deriveBadge(tasksCache, activeValues());
      setHidden(ui.badge, !badge);
      ui.badge.textContent = badge;
      ui.panel.innerHTML = panelHtml(tasksCache, { offline: offline, badge: badge });
    }
    function refreshRecent() {
      return send('recent').then(function (r) {
        if (r && r.ok) {
          applyOffline(false);
          tasksCache = Array.isArray(r.data) ? r.data : [];
          renderPanel();
          return;
        }
        if (isOffline(r)) applyOffline(true);
      }, function (e) { if (isOffline(e)) applyOffline(true); });
    }
    // 通道换肤：background 侧探活自带 TTL 缓存，5s 心跳不会每次真打后端。
    function refreshChannel() {
      return send('UI_PROBE').then(function (r) {
        var next = channelTheme(r && r.channel);
        if (next !== channel) { channel = next; render(); }
      }, function () { /* 探测失败：保持上一皮肤，下一心跳再试 */ });
    }
    function showPanel() {
      if (panelOpen) return;
      panelOpen = true;
      setHidden(ui.panel, false);
      refreshRecent();
      var tick = 0;
      panelTimer = win.setInterval(function () {
        refreshRecent().then(function () {
          tick++;
          var hint = ui && ui.panel.querySelector('[data-el="hint"]');
          if (hint) hint.textContent = offline ? TEXT.notConnected : TEXT.refreshHint + (tick * PANEL_REFRESH_MS / 1000) + 's';
        });
      }, PANEL_REFRESH_MS);
      render();
    }
    function hidePanel() {
      if (panelTimer) { win.clearInterval(panelTimer); panelTimer = null; }
      if (!panelOpen) return;
      panelOpen = false;
      if (ui) setHidden(ui.panel, true);
      render();
    }
    function onPanelClick(e) {
      var target = e.target && e.target.closest ? e.target.closest('[data-task-action]') : null;
      if (!target || target.disabled) return;
      target.disabled = true;
      var action = target.dataset.taskAction;
      var taskId = target.dataset.taskId;
      var req = action === 'retry' ? send('retry', { taskId: taskId })
        : action === 'delete' ? send('deleteTask', { taskId: taskId })
        : send('clearFinished');
      req.then(function (r) {
        if (r && !r.ok) throw apiFailure(r, '操作失败');
        return refreshRecent();
      }).catch(function (err) {
        if (isOffline(err)) applyOffline(true);
        // 面板里的操作失败不该打断正在进行的下载态，其余情况一律转成失败态把原因显示出来
        setPhase(phase === 'busy' ? 'busy' : 'err', { detail: errorMessage(err) });
      }).then(function () { target.disabled = false; });
    }
    function onDocPointerDown(e) {
      // shadow DOM 内的事件在 document 层被重定向为 host：target 不是 host 就说明点在了别处
      if (panelOpen && host && e.target !== host) hidePanel();
    }
    function onDocKeyDown(e) {
      if (panelOpen && (e.key === 'Escape' || e.keyCode === 27)) hidePanel();
    }

    /* ---------- 提交与轮询 ---------- */
    function schedulePoll(taskId, delay) {
      if (pollTimer) win.clearTimeout(pollTimer);
      var token = pollToken;
      pollTimer = win.setTimeout(function () { pollTimer = null; pollTask(taskId, token); }, delay);
    }
    function pollTask(taskId, token) {
      if (token !== pollToken) return; // 已被新的提交或卸载取代，旧轮询立刻闭嘴
      send('task', { taskId: taskId }).then(function (r) {
        if (token !== pollToken) return;
        if (!r || !r.ok) throw apiFailure(r, '任务查询失败'); // 用 .catch 收：then(ok, err) 接不住 ok 里抛的异常
        var task = r.data || {};
        if (task.status === 'completed') {
          forgetTask(taskId);
          refreshRecent();
          setPhase('ok', { detail: task.phase || TEXT.okFallback });
          return;
        }
        if (task.status === 'failed' || task.status === 'cancelled' || task.status === 'paused' || task.status === 'partial_failed') {
          forgetTask(taskId);
          refreshRecent();
          var item = (task.items || []).filter(function (i) { return i && i.error; })[0];
          setPhase('err', { detail: task.error || (item && item.error) || task.phase || TEXT.errFallback });
          return;
        }
        setPhase('busy', { detail: task.phase || TEXT.busyFallback });
        schedulePoll(taskId, POLL_MS);
      }).catch(function (e) {
        // 查询失败（客户端没开/连接断了）：立即清 active 并停轮询，否则按钮永久卡在「下载中」
        if (token !== pollToken) return;
        forgetTask(taskId);
        refreshRecent();
        if (isOffline(e)) applyOffline(true);
        setPhase('err', { detail: errorMessage(e) });
      });
    }
    function save() {
      if (phase === 'busy') return; // 连点防线
      var url = contentApi.currentTarget();
      if (!url) { check(); return; }
      if (active[url]) { setPhase('busy', { detail: TEXT.sameUrl }, true); return; }
      var token = ++pollToken;
      active[url] = 'pending';
      renderPanel();
      // 公众号：正文与媒体由桌面端采集窗口抓取，扩展只递交网址（SAVE_WECHAT）。
      // X：走原有 SAVE_START，background 页面内提取 → 三通道选路 → 返回终态。
      var kind = typeof contentApi.pageKind === 'function' ? contentApi.pageKind() : 'x';
      var wechat = kind === 'wechat';
      // 挂载后开关被关掉（设置页取消勾选与按钮点击抢在同一帧）：不递交，顺手把入口撤了
      if (wechat && !wechatEnabled) { check(); return; }
      setPhase('busy', { detail: wechat ? TEXT.wechatSubmitting : TEXT.submitting });
      send(wechat ? 'SAVE_WECHAT' : 'SAVE_START', wechat ? {url: url} : {}).then(function (r) {
        if (token !== pollToken) return;
        if (!r || !r.ok) throw apiFailure(r, '保存失败');
        if (r.channel === 'desktop' && r.taskId) {
          active[url] = r.taskId;
          setPhase('busy', { detail: TEXT.submitted });
          schedulePoll(r.taskId, POLL_FIRST_MS);
          renderPanel();
          return;
        }
        delete active[url];
        renderPanel();
        if (r.channel === 'duplicate') { // 桌面端已有这篇（公众号通道的判重）
          setPhase('ok', { detail: TEXT.duplicate });
          return;
        }
        var detail = r.channel === 'queued' ? TEXT.syncedQueued
          : r.channel === 'download' ? TEXT.syncedDownload
          : TEXT.syncedBackend;
        setPhase('ok', { detail: detail });
      }).catch(function (e) {
        delete active[url];
        if (token !== pollToken) return;
        if (isOffline(e)) applyOffline(true); // 桌面桥接离线：面板转离线态，保存本身已由三通道兜底
        setPhase('err', { detail: errorMessage(e) });
        renderPanel();
      });
    }

    // background → tab 推送：仅刷新 busy 进度细节；终态（done/queued/error）以 SAVE_START 响应为单源，
    // 避免推送与应答双源竞态。desktop 通道的进度由 task 轮询负责。
    function onRuntimeMessage(msg) {
      // 快捷键（background 侧判定页面可存后通知本帧）：与点按钮同一条 save() 链路
      if (msg && msg.type === 'SAVE_CURRENT') { save(); return; }
      var s = msg && msg.type === 'EXPORT_STATE' && msg.state;
      if (!s || phase !== 'busy') return;
      if (s.phase === 'extracting' || s.phase === 'pushing' || s.phase === 'uploading' || s.phase === 'building') {
        setPhase('busy', { detail: s.message || TEXT.busyFallback }, true);
      }
    }

    /* ---------- 拖拽（Pointer Events；transform 走合成层 + rAF 合帧，松手按「最后指针位置」落定） ---------- */
    function onPointerDown(ev) {
      if (ev.button !== 0) return;
      // 按下时一次性读取几何；move 过程中绝不碰 offsetWidth/offsetLeft（会强制 reflow）
      var rect = host.getBoundingClientRect();
      var m = metrics();
      var btnW = rect.width || m.w, btnH = rect.height || m.h;
      var grabDX = ev.clientX - rect.left, grabDY = ev.clientY - rect.top;
      var downX = ev.clientX, downY = ev.clientY;
      var moved = false, rafId = 0;
      var pendingX = rect.left, pendingY = rect.top; // 初值即当前位置：一次 move 都没合成也有正确落定值

      if (pressTimer) win.clearTimeout(pressTimer);
      pressTimer = win.setTimeout(function () { // 长按 = 切换胶囊/圆钮；切换后位置要按新尺寸重新钳位
        pressTimer = null;
        moved = true; // 长按不是点击，别让它顺带触发保存
        dragged = true;
        collapsed = !collapsed;
        render();
        persistCollapsed();
        applyPos();
      }, PRESS_TOGGLE_MS);

      function targetAt(x, y) { return clampPos(x - grabDX, y - grabDY, btnW, btnH, m.vw, m.vh); }
      function flush() {
        rafId = 0;
        var clamped = targetAt(pendingX, pendingY);
        host.style.transform = 'translate3d(' + (clamped.x - rect.left) + 'px,' + (clamped.y - rect.top) + 'px,0)';
        pos = clamped;
      }
      function onMove(e2) {
        // 阈值看「相对按下点移动了多远」：按下瞬间相对按钮左上角天然就有 grab 偏移
        var dx = e2.clientX - downX, dy = e2.clientY - downY;
        if (!moved && Math.abs(dx) + Math.abs(dy) <= DRAG_THRESHOLD_PX) return;
        if (!moved) {
          moved = true;
          dragged = true;
          if (pressTimer) { win.clearTimeout(pressTimer); pressTimer = null; }
          host.setAttribute('data-dragging', '1');
        }
        pendingX = e2.clientX;
        pendingY = e2.clientY;
        if (rafId) return; // 一帧只排一次更新
        rafId = win.requestAnimationFrame(flush);
      }
      // commit=true 落定到新位置；false（未过阈值的点击/仅长按）只清场，不留半截 transform
      function finish(commit) {
        win.removeEventListener('pointermove', onMove);
        win.removeEventListener('pointerup', onUp);
        win.removeEventListener('pointercancel', onCancel);
        if (rafId) { win.cancelAnimationFrame(rafId); rafId = 0; }
        if (pressTimer) { win.clearTimeout(pressTimer); pressTimer = null; }
        host.removeAttribute('data-dragging');
        if (commit) {
          // 用「最后一次指针位置」同步重算，而不是可能尚未 flush 的旧 pos —— 否则快拖松手会回弹
          pos = targetAt(pendingX, pendingY);
          host.style.transform = '';
          applyPos();
          persistPos();
        } else {
          host.style.transform = '';
        }
      }
      function onUp() { finish(moved); }
      function onCancel() { finish(moved); } // 手势被系统打断时停在最后位置，别留视觉残留
      win.addEventListener('pointermove', onMove);
      win.addEventListener('pointerup', onUp);
      win.addEventListener('pointercancel', onCancel);
    }

    /* ---------- DOM 构建 ---------- */
    function build() {
      var frag = doc.createElement('div');
      frag.setAttribute('data-el', 'root');
      frag.className = 'fx';

      var main = doc.createElement('button');
      main.setAttribute('data-el', 'main');
      main.type = 'button';
      main.className = 'fx-main';
      var ico = doc.createElement('span');
      ico.className = 'fx-ico';
      ico.setAttribute('aria-hidden', 'true');
      var icons = {
        idle: icon(['M12 3v11', 'm7 9.5 5 5 5-5', 'M4.5 19.5h15']),
        busy: icon(['M21 12a9 9 0 1 1-2.7-6.4'], 'fx-spin'),
        ok: icon(['M5 12.5l4.5 4.5L19.5 7']),
        err: icon(['M12 8v5', 'M12 17h.01', 'M10.3 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.7 3.86a2 2 0 0 0-3.4 0Z']),
        offline: icon(['M2 8.82a15 15 0 0 1 20 0', 'M5 12.86a10 10 0 0 1 14 0', 'M8.5 16.43a5 5 0 0 1 7 0', 'M12 20h.01', 'M3 3l18 18']),
        panel: icon(['M4 6h16', 'M4 12h16', 'M4 18h10']),
        close: icon(['M6 6l12 12', 'M18 6 6 18'])
      };
      // 初始只留 idle 图标可见；其余显隐一律交 render()（单写者，避免图标与文案不同源）
      ['busy', 'ok', 'err', 'offline', 'panel'].forEach(function (k) { setHidden(icons[k], true); });
      ico.appendChild(icons.idle);
      ico.appendChild(icons.busy);
      ico.appendChild(icons.ok);
      ico.appendChild(icons.err);
      ico.appendChild(icons.offline);
      var label = doc.createElement('span');
      label.setAttribute('data-el', 'label');
      label.className = 'fx-label';
      main.appendChild(ico);
      main.appendChild(label);

      var mini = doc.createElement('button');
      mini.setAttribute('data-el', 'expand');
      mini.type = 'button';
      mini.className = 'fx-mini';
      var miniIco = doc.createElement('span');
      miniIco.setAttribute('aria-hidden', 'true');
      miniIco.appendChild(icons.panel);
      miniIco.appendChild(icons.close);
      mini.appendChild(miniIco);

      var badge = doc.createElement('span');
      badge.setAttribute('data-el', 'badge');
      badge.className = 'fx-badge';
      var notice = doc.createElement('div');
      notice.setAttribute('data-el', 'notice');
      notice.className = 'fx-notice';
      notice.setAttribute('role', 'status');
      notice.setAttribute('hidden', ''); // 首帧就隐身：状态文案由 render() 决定何时亮起来
      var panel = doc.createElement('div');
      panel.setAttribute('data-el', 'panel');
      panel.className = 'fx-panel';
      panel.setAttribute('hidden', '');

      frag.appendChild(main);
      frag.appendChild(mini);
      frag.appendChild(badge);
      frag.appendChild(notice);
      frag.appendChild(panel);
      return { root: frag, main: main, label: label, mini: mini, badge: badge, notice: notice, panel: panel, icons: icons };
    }

    /* ---------- 挂载 / 卸载 ---------- */
    this.mount = function () {
      if (host) return;
      var existing = doc.getElementById(HOST_ID);
      if (existing && existing.__fxCtl) return; // 同帧已有控制器：不建第二个宿主
      host = existing || doc.createElement('div');
      if (!existing) {
        host.id = HOST_ID;
        host.setAttribute('lang', 'zh-CN');
        host.attachShadow({ mode: 'open' }); // 样式双向隔离：X 的原子类与本页互不穿透
      } else if (host.shadowRoot) {
        // 宿主是旧版脚本留下的：不清空就会和 1.6.x 那颗按钮叠成两个
        host.shadowRoot.innerHTML = '';
      }
      host.__fxCtl = self;
      ui = build();
      var style = doc.createElement('style');
      style.textContent = CSS;
      host.shadowRoot.appendChild(style);
      host.shadowRoot.appendChild(ui.root);
      if (!pos) pos = defaultPos(metrics());
      render();
      renderPanel();
      doc.documentElement.appendChild(host);
      // 记忆坐标是「本帧视口」里的位置，但存储是全局共享的；尺寸只有插进文档才量得到，
      // 故插入后再按当前视口收一次（气泡/面板的贴边翻转也一并跟上）
      applyPos();
      ui.main.addEventListener('pointerdown', onPointerDown);
      ui.main.addEventListener('click', function (ev) {
        if (dragged) { dragged = false; if (ev.preventDefault) ev.preventDefault(); return; }
        save();
      });
      if (chromeApi.runtime && chromeApi.runtime.onMessage) {
        chromeApi.runtime.onMessage.addListener(onRuntimeMessage);
      }
      ui.mini.addEventListener('click', function () { if (panelOpen) hidePanel(); else showPanel(); });
      ui.panel.addEventListener('click', onPanelClick);
      doc.addEventListener('keydown', onDocKeyDown, true);
      doc.addEventListener('pointerdown', onDocPointerDown, true);
      win.addEventListener('resize', applyPos);
      recentTimer = win.setInterval(function () { refreshRecent(); refreshChannel(); }, RECENT_MS);
      refreshRecent();
      refreshChannel();
      this.attached = true;
    };

    this.unmount = function () {
      if (resetTimer) { win.clearTimeout(resetTimer); resetTimer = null; }
      if (pressTimer) { win.clearTimeout(pressTimer); pressTimer = null; }
      if (pollTimer) { win.clearTimeout(pollTimer); pollTimer = null; }
      if (recentTimer) { win.clearInterval(recentTimer); recentTimer = null; }
      if (panelTimer) { win.clearInterval(panelTimer); panelTimer = null; }
      pollToken++; // 在途的 sendMessage 回来后一律作废
      if (chromeApi.runtime && chromeApi.runtime.onMessage && chromeApi.runtime.onMessage.removeListener) {
        chromeApi.runtime.onMessage.removeListener(onRuntimeMessage);
      }
      if (host) {
        win.removeEventListener('resize', applyPos);
        doc.removeEventListener('keydown', onDocKeyDown, true);
        doc.removeEventListener('pointerdown', onDocPointerDown, true);
        if (host.parentNode) host.parentNode.removeChild(host);
        host.__fxCtl = null;
      }
      host = null;
      ui = null;
      panelOpen = false;
      phase = 'idle';
      info = null;
      this.attached = false;
    };

    /* ---------- 探活观察 ---------- */
    function isSelfMutation(rec) {
      var t = rec.target;
      if (host && (t === host || (host.contains && host.contains(t)))) return true;
      var lists = [rec.addedNodes, rec.removedNodes];
      for (var i = 0; i < lists.length; i++) {
        var list = lists[i];
        if (!list) continue;
        for (var j = 0; j < list.length; j++) if (list[j] === host) return true;
      }
      return false;
    }
    function check() {
      var ok;
      // 探测层抛错按不可存处理；站点开关关掉时该页直接不亮（公众号默认态）
      try { ok = enabled && siteAllowed(contentApi, wechatEnabled) && !!contentApi.probe(); } catch (e) { ok = false; }
      if (ok && !host) self.mount();
      else if (!ok && host) self.unmount();
    }
    self.check = check;
    function scheduleCheck() {
      if (checkTimer) return;
      checkTimer = win.setTimeout(function () { checkTimer = null; check(); }, THROTTLE_MS);
    }
    this.watch = function () {
      check();
      if (observer) return;
      observer = new win.MutationObserver(function (records) {
        for (var i = 0; i < records.length; i++) {
          if (isSelfMutation(records[i])) return; // 自身注入/卸载不得回灌观察器（否则抖动时自激振荡）
        }
        scheduleCheck();
      });
      observer.observe(doc.documentElement, { childList: true, subtree: true });
      // 纯 pushState 换页可能一帧 DOM 都不动（时间线缓存命中），靠路由事件补一次复检，
      // 不再用 1 秒轮询去兜 —— 那才是 1.6.x 观察器空转的根因。
      win.addEventListener('popstate', scheduleCheck);
      win.addEventListener('hashchange', scheduleCheck);
    };
    this.dispose = function () {
      if (observer) { observer.disconnect(); observer = null; }
      win.removeEventListener('popstate', scheduleCheck);
      win.removeEventListener('hashchange', scheduleCheck);
      if (checkTimer) { win.clearTimeout(checkTimer); checkTimer = null; }
      self.unmount();
    };
    this.settingsChanged = function (next) {
      if (next && next.position !== undefined) {
        var p = validPos(next.position);
        if (p && (!pos || p.x !== pos.x || p.y !== pos.y)) { pos = p; applyPos(); }
      }
      if (next && next[COLLAPSE_KEY] !== undefined && !!next[COLLAPSE_KEY] !== collapsed) {
        collapsed = !!next[COLLAPSE_KEY];
        render();
        applyPos();
      }
      if (next && next[ENABLED_KEY] !== undefined) {
        enabled = next[ENABLED_KEY] !== false;
        check();
      }
      if (next && next[WECHAT_KEY] !== undefined) {
        wechatEnabled = next[WECHAT_KEY] === true;
        check(); // 设置页勾选后当前公众号页即时亮起/熄灭，不必刷新
      }
    };
  }

  /* ---------- 装配入口 ---------- */
  // 与姊妹扩展同一思路：真机排查「没按钮」时要能一眼分清是未注入、被开关关掉、还是这页没有可存目标
  function trace(res) {
    if (root.__DOWNX_NO_DEBUG || typeof console === 'undefined' || !console.debug) return res;
    console.debug('[DownX] floating ' + (res.mounted ? '已挂载' : '未挂载：' + res.reason), location.href);
    return res;
  }

  function boot(deps) {
    deps = deps || {};
    var doc = deps.doc, chromeApi = deps.chromeApi, contentApi = deps.contentApi;
    if (!contentApi || typeof contentApi.probe !== 'function') {
      return Promise.resolve(trace({ mounted: false, reason: 'no-content-api' })); // 注入顺序被破坏：整体静默
    }
    var kv = {};
    kv[POSITION_KEY] = null;
    kv[COLLAPSE_KEY] = false;
    kv[ENABLED_KEY] = true;
    kv[WECHAT_KEY] = false;
    return Promise.resolve(chromeApi.storage.local.get(kv)).then(function (cfg) {
      cfg = cfg || {};
      var ctl = new Controller(deps, cfg);
      watch(ctl, deps);
      return trace(ctl.attached ? { mounted: true } : { mounted: false, reason: mountReason(cfg, contentApi) });
    }, function () {
      // 读不到设置就无从知道用户是否关掉过入口 —— 此时不挂载：宁可少一个入口，也不在诊断不了的环境里改页面
      return trace({ mounted: false, reason: 'storage-unavailable' });
    });
  }

  function watch(ctl, deps) {
    ctl.watch();
    var storage = deps.chromeApi.storage;
    if (storage.onChanged) {
      storage.onChanged.addListener(function (changes, area) {
        if (area !== 'local') return;
        var next = {};
        [POSITION_KEY, COLLAPSE_KEY, ENABLED_KEY, WECHAT_KEY].forEach(function (k) { if (changes[k]) next[k] = changes[k].newValue; });
        ctl.settingsChanged(next);
      });
    }
    if (deps.win.addEventListener) deps.win.addEventListener('pagehide', function () { ctl.dispose(); }, { once: true });
  }

  var api = {
    boot: boot, canAutoStart: canAutoStart, Controller: Controller,
    siteAllowed: siteAllowed, mountReason: mountReason,
    clampPos: clampPos, validPos: validPos, phaseText: phaseText, errorMessage: errorMessage,
    isOffline: isOffline, deriveBadge: deriveBadge, itemCount: itemCount, truncateTitle: truncateTitle,
    channelTheme: channelTheme, CHANNEL_NAME: CHANNEL_NAME,
    statusLabel: statusLabel, statusDot: statusDot, progressWidth: progressWidth, panelHtml: panelHtml, esc: esc,
    HOST_ID: HOST_ID, POSITION_KEY: POSITION_KEY, COLLAPSE_KEY: COLLAPSE_KEY, ENABLED_KEY: ENABLED_KEY,
    WECHAT_KEY: WECHAT_KEY, TEXT: TEXT,
    THROTTLE_MS: THROTTLE_MS, EDGE_PX: EDGE_PX, DRAG_THRESHOLD_PX: DRAG_THRESHOLD_PX, PRESS_TOGGLE_MS: PRESS_TOGGLE_MS,
    DONE_RESET_MS: DONE_RESET_MS, ERROR_RESET_MS: ERROR_RESET_MS, POLL_MS: POLL_MS, POLL_FIRST_MS: POLL_FIRST_MS,
    RECENT_MS: RECENT_MS, PANEL_REFRESH_MS: PANEL_REFRESH_MS, CIRCLE_PX: CIRCLE_PX
  };
  root.__floatingTest = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;

  /* ---------- 实时装配：仅在真帧内执行（node/jsdom 导入期不碰 DOM） ---------- */
  if (typeof document !== 'undefined' && typeof chrome !== 'undefined') {
    var auto = { doc: document, win: root, chromeApi: chrome, contentApi: root.DownXContent };
    if (canAutoStart(auto)) {
      Promise.resolve(boot(auto)).catch(function () { /* 装配失败不得干扰 X 正常页面 */ });
    }
  }
})(typeof self !== 'undefined' ? self : globalThis);
