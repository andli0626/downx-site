// options.js · 设置页：同步通道 / 后端地址（含动态 host 权限申请）/ 桌面桥接
// 后端地址保存时需 chrome.permissions.request 申请 optional_host_permissions，
// 拒绝授权则中止保存（后端通道无法跨域访问）。
// 地址切换（对标 Android ServerConfigScreen）：历史+预置下拉、选中回填并自动复测、
// 验证成功自动入档（去重置顶上限 10，桌面端地址与令牌成对）、局域网自动发现扫描。
// 预置地址：优先用后端集中管理的服务地址注册表（GET /api/server-endpoints?platform=ext），
// 缓存于 chrome.storage.local 的 xdocServerEndpoints，拉取失败退回缓存 / 内置兜底表。
// 页面入口的解析纯逻辑在 entry-urls.js（与弹窗共用同一份派生口径）。
const SC = self.DownXSyncChannel;
const SH = self.DownXServerHistory;
const EU = self.DownXEntryUrls;
const TEST_TIMEOUT_MS = 5000;
const getUrlOf = (e) => e.url;

// 入口地址存储 key：设置页读写与弹窗解析共用同一份默认值
const ENTRY_KEYS = {webEntryUrl: '', h5EntryUrl: '', downloadEntryUrl: '', appEntryUrl: ''};
const defaults = Object.assign(
  {
    baseUrl: 'http://127.0.0.1:17321',
    token: '',
    autoSync: true,
    enabled: true,
    wechatEnabled: false,
    syncChannelMode: 'auto',
    backendEndpoint: '',
    backendToken: '',
    preferLargeImage: true,
    backendHistory: [],
    desktopHistory: [],
    xdocServerEndpoints: null,
  },
  ENTRY_KEYS,
);

// 预置服务器地址 — 内置兜底表：与 Android ServerConfigScreen.PRESET_SERVERS_DEMO 同源。
// 后端注册表拉不到（未配置地址 / 离线 / 接口异常）时才使用，禁止清空。
const PRESET_SERVERS = [
  {label: 'NAS 本地', url: 'http://192.168.10.222:6688'},
  {label: 'NAS ZeroTier', url: 'http://172.26.8.33:6688'},
  {label: 'Mac Home', url: 'http://192.168.10.91:6688'},
  {label: 'Mac Epoint', url: 'http://172.20.244.219:6688'},
  {label: 'Mac Visitor', url: 'http://172.20.237.106:6688'},
  {label: 'Mac Zero', url: 'http://172.26.199.169:6688'},
  {label: 'HW Epoint', url: 'http://172.20.244.228:6688'},
  {label: 'HW Zero', url: 'http://172.26.172.248:6688'},
  {label: 'OldMac Zero', url: 'http://172.26.98.131:6688'},
  {label: '本机 localhost', url: 'http://127.0.0.1:6688'},
  {label: '权威 Mac', url: 'http://172.20.246.65:16655'},
];
const DESKTOP_PRESETS = [
  {label: '本机 DownX', url: 'http://127.0.0.1:17321'},
];

const state = {
  backendHistory: [],
  desktopHistory: [],
  scanning: false,
  scanAbort: false,
  serverPresets: [],
  serverVersion: '',
  endpointsAt: 0,
  guideDismissed: false,
};

const normalizeEndpoint = EU.normalizeEndpoint;

/* ---------- 服务地址注册表（后端 xdoc-api 集中管理：缓存优先、内置兜底） ---------- */

const ENDPOINTS_KEY = 'xdocServerEndpoints';
const ENDPOINTS_PLATFORM = 'ext';
const ENDPOINTS_TIMEOUT_MS = 4000;
// 打开设置页每次都打后端没必要，10 分钟内复用上次结果；「刷新地址」按钮强制拉取。
const ENDPOINTS_TTL_MS = 10 * 60 * 1000;
const ENDPOINTS_MAX_BASES = 10;

function normalizePreset(p) {
  if (!p) return null;
  const url = normalizeEndpoint(p.url || p.baseUrl);
  if (!url) return null;
  return {
    label: String(p.label || p.name || url),
    url: url,
    pairing: p.requiresPairing === true || p.pairing === true,
  };
}

function normalizePresetList(list) {
  return (Array.isArray(list) ? list : []).map(normalizePreset).filter(Boolean);
}

// 预设列表在任何情况下都非空：注册表缓存不可用即回落到内置兜底表。
function presetList() {
  return state.serverPresets.length ? state.serverPresets : PRESET_SERVERS;
}

function cachedEndpoints() {
  return state.serverPresets.length
    ? {version: state.serverVersion, items: state.serverPresets, at: state.endpointsAt}
    : null;
}

function applyEndpointCache(cached) {
  const items = normalizePresetList(cached && cached.items);
  state.serverPresets = items;
  state.serverVersion = String((cached && cached.version) || '');
  state.endpointsAt = Number(cached && cached.at) || 0;
  return items.length;
}

/** 向单个服务根地址拉注册表；超时 / 非 200 / code!=0 / 解析失败 / 空清单一律返回 null。 */
async function fetchServerEndpoints(base) {
  try {
    const r = await SC.fetchWithTimeout(
      fetch,
      base + '/api/server-endpoints?platform=' + ENDPOINTS_PLATFORM,
      {headers: {Accept: 'application/json'}},
      ENDPOINTS_TIMEOUT_MS,
    );
    if (!r.ok) return null;
    const data = SC.unwrapR(await r.json());
    const items = normalizePresetList(data && data.items);
    if (!items.length) return null;
    return {version: String((data && data.version) || ''), items: items, source: base, at: Date.now()};
  } catch (e) {
    return null;
  }
}

// 候选服务根地址：当前填写的地址优先，其次历史与缓存，最后内置表。
function endpointCandidateBases() {
  const list = [];
  const push = (raw) => {
    const url = normalizeEndpoint(typeof raw === 'string' ? raw : raw && raw.url);
    if (url && list.indexOf(url) < 0) list.push(url);
  };
  push(backendEndpoint.value);
  for (const h of state.backendHistory) push(h);
  for (const p of state.serverPresets) push(p);
  for (const p of PRESET_SERVERS) push(p);
  return list.slice(0, ENDPOINTS_MAX_BASES);
}

async function grantedBases(bases) {
  const flags = await Promise.all(
    bases.map(async (b) => {
      try {
        return !!(await chrome.permissions.contains({origins: [b + '/*']}));
      } catch (e) {
        return false;
      }
    }),
  );
  return bases.filter((_, i) => flags[i]);
}

// 只在用户点击「刷新地址」时申请（MV3 要求用户手势），页内自动拉取不打扰授权。
async function requestBases(bases) {
  if (!bases.length) return [];
  let granted = false;
  try {
    granted = await chrome.permissions.request({origins: bases.map((b) => b + '/*')});
  } catch (e) {
    granted = false;
  }
  return granted ? bases : [];
}

let endpointsBusy = null;
let renderedPresetSig = '';

function presetSignature() {
  return presetList().map((p) => p.label + '|' + p.url + '|' + (p.pairing ? '1' : '')).join('');
}

function presetSub(p) {
  return p.pairing ? p.label + ' · 需配对' : p.label;
}

/**
 * 拉取注册表并写入 chrome.storage.local。
 * version 未变即复用缓存不覆写；失败保留旧缓存（没缓存就是内置表），全程不抛错。
 */
function refreshServerEndpoints(opts) {
  const force = !!(opts && opts.force);
  if (endpointsBusy) return endpointsBusy;
  const cached = cachedEndpoints();
  if (!force && cached && Date.now() - cached.at < ENDPOINTS_TTL_MS) return Promise.resolve(cached);
  const askPermission = !!(opts && opts.askPermission);
  const run = (async () => {
    const bases = endpointCandidateBases();
    // 手动刷新在用户手势里第一时间申请权限（已授权的原静默通过），自动拉取只走已授权地址。
    let targets = askPermission ? await requestBases(bases) : await grantedBases(bases);
    if (!targets.length && askPermission) targets = await grantedBases(bases);
    if (!targets.length) return cached;
    const hits = await Promise.all(targets.map((b) => fetchServerEndpoints(b)));
    const next = hits.find(Boolean);
    if (!next) return cached;
    if (cached && cached.version && next.version === cached.version) return cached;
    state.serverPresets = next.items;
    state.serverVersion = next.version;
    state.endpointsAt = next.at;
    await persist({
      [ENDPOINTS_KEY]: {version: next.version, items: next.items, source: next.source, at: next.at},
    });
    return next;
  })()
    .catch(() => cached)
    .finally(() => {
      if (endpointsBusy === run) endpointsBusy = null;
    });
  endpointsBusy = run;
  return run;
}

/* ---------- 初始化（含就绪 Promise：供测试 await 整条 静默刷新 → 自动检测 链路） ---------- */

let resolveReady;
const ready = new Promise((r) => {
  resolveReady = r;
});

chrome.storage.local.get(defaults, (s) => {
  baseUrl.value = s.baseUrl;
  token.value = s.token;
  autoSync.checked = s.autoSync;
  // 站点开关：enabled 缺省即开（老用户从未写过它），wechatEnabled 缺省即关（默认只认 X）
  floatEnabled.checked = s.enabled !== false;
  wechatEnabled.checked = s.wechatEnabled === true;
  syncChannelMode.value = ['auto', 'backend', 'desktop'].includes(s.syncChannelMode) ? s.syncChannelMode : 'auto';
  backendEndpoint.value = s.backendEndpoint || '';
  backendToken.value = s.backendToken || '';
  preferLargeImage.checked = s.preferLargeImage !== false;
  state.backendHistory = Array.isArray(s.backendHistory) ? s.backendHistory : [];
  state.desktopHistory = Array.isArray(s.desktopHistory) ? s.desktopHistory : [];
  webEntryUrl.value = s.webEntryUrl || '';
  h5EntryUrl.value = s.h5EntryUrl || '';
  appEntryUrl.value = s.appEntryUrl || '';
  downloadEntryUrl.value = s.downloadEntryUrl || '';
  applyEndpointCache(s.xdocServerEndpoints);
  scanSubnet.value = defaultSubnet(backendEndpoint.value);
  // 打开设置页静默拉一次：只走已授权地址，失败不提示、不打断面板（预设列表始终非空）。
  // 拉取完成后：后端地址未配置 → 自动检测引导（只呈现候选，绝不自动写入地址）。
  const afterInit = async () => {
    try {
      await refreshServerEndpoints({force: false});
      if (!backendPanel.hidden && presetSignature() !== renderedPresetSig) renderBackendPanel();
    } catch (e) {
      /* 静默失败：检测异常永不阻断选项页 */
    }
    try {
      if (!String(backendEndpoint.value || '').trim()) await autoGuideBackend();
    } catch (e) {
      /* 同上 */
    }
    resolveReady();
  };
  afterInit();
});

function persist(partial) {
  return new Promise((res) => chrome.storage.local.set(partial, res));
}

/* ---------- 地址自测验证 ---------- */

function setTest(el, cls, text) {
  el.textContent = text;
  el.className = 'test' + (cls ? ' ' + cls : '');
}

function fetchErrorText(e) {
  if (e && e.name === 'AbortError') return '连接超时';
  return (e && e.message) || String(e);
}

// SyncError（HTTP 分类）自带友好文案；裸 fetch 网络错误统一归为不可达
function probeErrorText(e) {
  if (e && e.kind) return e.message;
  if (e && e.name === 'AbortError') return '连接超时';
  return '无法连接（网络或地址不可达）';
}

// 后端：GET /api/health（R 信封），未授权时先走与保存一致的 host 权限申请
testBackend.onclick = async () => {
  const endpoint = normalizeEndpoint(backendEndpoint.value);
  if (endpoint === null) return setTest(backendTestMsg, 'bad', '✗ 地址无效：需为 http/https URL');
  if (!endpoint) return setTest(backendTestMsg, 'bad', '✗ 请先填写后端地址');
  testBackend.disabled = true;
  try {
    let granted = false;
    try {
      granted = await chrome.permissions.contains({origins: [endpoint + '/*']});
    } catch (e) {
      granted = false;
    }
    if (!granted) {
      setTest(backendTestMsg, 'wait', '未授权，正在申请访问权限…');
      try {
        granted = await chrome.permissions.request({origins: [endpoint + '/*']});
      } catch (e) {
        granted = false;
      }
      if (!granted) return setTest(backendTestMsg, 'bad', '✗ 未获得访问权限，无法验证');
    }
    setTest(backendTestMsg, 'wait', '检测中…');
    const t0 = Date.now();
    const r = await SC.fetchWithTimeout(
      fetch,
      endpoint + '/api/health',
      {headers: {Accept: 'application/json'}},
      TEST_TIMEOUT_MS,
    );
    if (!r.ok) throw SC.syncErrorFromResponse(r.status, '');
    const data = SC.unwrapR(await r.json());
    setTest(
      backendTestMsg,
      'ok',
      `✓ 后端在线（${data.version || '版本未知'}，${Date.now() - t0}ms）`,
    );
    await pushBackendHistory(endpoint);
  } catch (e) {
    setTest(backendTestMsg, 'bad', '✗ 验证失败：' + probeErrorText(e));
    // 探活失败 → 出同款自动检测引导（内部含 dismissed 与容器缺失守卫，绝不阻断本页）
    Promise.resolve(autoGuideBackend()).catch(() => {});
  } finally {
    testBackend.disabled = false;
  }
};

// 桌面端：GET /health（Bearer 令牌），验证地址连通性与令牌有效性
testDesktop.onclick = async () => {
  const base = String(baseUrl.value || '').trim().replace(/\/+$/, '');
  if (!base) return setTest(desktopTestMsg, 'bad', '✗ 请先填写本机地址');
  try {
    const u = new URL(base);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error();
  } catch (e) {
    return setTest(desktopTestMsg, 'bad', '✗ 地址无效：需为 http/https URL');
  }
  testDesktop.disabled = true;
  setTest(desktopTestMsg, 'wait', '检测中…');
  const t0 = Date.now();
  try {
    const headers = {Accept: 'application/json'};
    if (token.value) headers.Authorization = 'Bearer ' + token.value;
    const r = await SC.fetchWithTimeout(fetch, base + '/health', {headers}, TEST_TIMEOUT_MS);
    if (r.status === 401 || r.status === 403)
      return setTest(desktopTestMsg, 'bad', '✗ 地址可达，但访问令牌无效（HTTP ' + r.status + '）');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json().catch(() => null);
    setTest(
      desktopTestMsg,
      'ok',
      `✓ 桌面端在线${data && data.version ? `（${data.version}）` : ''}，${Date.now() - t0}ms`,
    );
    await pushDesktopHistory(base, token.value);
  } catch (e) {
    setTest(desktopTestMsg, 'bad', '✗ 桌面端不可达：' + fetchErrorText(e));
  } finally {
    testDesktop.disabled = false;
  }
};

// 地址/令牌变更后旧结果即失效
backendEndpoint.addEventListener('input', () => setTest(backendTestMsg, '', ''));
baseUrl.addEventListener('input', () => setTest(desktopTestMsg, '', ''));
token.addEventListener('input', () => setTest(desktopTestMsg, '', ''));

/* ---------- 历史入档（验证成功即写入，对标 Android testConnection 成功后写历史） ---------- */

async function pushBackendHistory(endpoint) {
  state.backendHistory = SH.addHistory(state.backendHistory, endpoint);
  await persist({backendHistory: state.backendHistory});
}

async function pushDesktopHistory(base, tk) {
  state.desktopHistory = SH.addHistory(state.desktopHistory, {url: base, token: tk || ''}, getUrlOf);
  await persist({desktopHistory: state.desktopHistory});
}

/* ---------- 历史 / 预置下拉面板 ---------- */

function clearPanel(panel) {
  while (panel.firstChild) panel.removeChild(panel.firstChild);
}

function makeItem(text, sub, onClick, onDelete) {
  const row = document.createElement('div');
  row.className = 'item';
  const u = document.createElement('span');
  u.className = 'u';
  u.textContent = text;
  row.appendChild(u);
  if (sub) {
    const s = document.createElement('span');
    s.className = 't';
    s.textContent = sub;
    row.appendChild(s);
  }
  row.addEventListener('click', onClick);
  if (onDelete) {
    const d = document.createElement('button');
    d.type = 'button';
    d.className = 'del';
    d.textContent = '✕';
    d.title = '删除此条记录';
    d.addEventListener('click', (ev) => {
      ev.stopPropagation();
      onDelete();
    });
    row.appendChild(d);
  }
  return row;
}

function sectionTitle(text) {
  const h = document.createElement('h4');
  h.textContent = text;
  return h;
}

function renderBackendPanel() {
  clearPanel(backendPanel);
  renderedPresetSig = presetSignature();
  backendPanel.appendChild(sectionTitle(state.serverPresets.length ? '预置地址（云端注册表）' : '预置地址'));
  for (const p of presetList()) {
    backendPanel.appendChild(makeItem(p.url, presetSub(p), () => applyBackend(p.url)));
  }
  if (state.backendHistory.length) {
    backendPanel.appendChild(sectionTitle('历史记录'));
    for (const url of state.backendHistory) {
      backendPanel.appendChild(
        makeItem(url, null, () => applyBackend(url), async () => {
          state.backendHistory = SH.removeHistory(state.backendHistory, url);
          await persist({backendHistory: state.backendHistory});
          renderBackendPanel();
        }),
      );
    }
  }
}

function renderDesktopPanel() {
  clearPanel(desktopPanel);
  desktopPanel.appendChild(sectionTitle('预置地址'));
  for (const p of DESKTOP_PRESETS) {
    desktopPanel.appendChild(makeItem(p.url, p.label, () => applyDesktop(p.url, null)));
  }
  if (state.desktopHistory.length) {
    desktopPanel.appendChild(sectionTitle('历史记录'));
    for (const e of state.desktopHistory) {
      desktopPanel.appendChild(
        makeItem(e.url, e.token ? '带令牌' : null, () => applyDesktop(e.url, e.token), async () => {
          state.desktopHistory = SH.removeHistory(state.desktopHistory, e.url, getUrlOf);
          await persist({desktopHistory: state.desktopHistory});
          renderDesktopPanel();
        }),
      );
    }
  }
}

// 选中即回填并自动复测（与 Android 行为一致）
function applyBackend(url) {
  backendEndpoint.value = url;
  backendPanel.hidden = true;
  setTest(backendTestMsg, '', '');
  return testBackend.onclick();
}

function applyDesktop(url, tk) {
  baseUrl.value = url;
  if (tk !== null && tk !== undefined) token.value = tk;
  desktopPanel.hidden = true;
  setTest(desktopTestMsg, '', '');
  return testDesktop.onclick();
}

function togglePanel(panel, other, render) {
  const show = panel.hidden;
  other.hidden = true;
  panel.hidden = !show;
  if (show) render();
}

backendDd.onclick = () => togglePanel(backendPanel, desktopPanel, renderBackendPanel);
desktopDd.onclick = () => togglePanel(desktopPanel, backendPanel, renderDesktopPanel);

// 手动刷新服务地址列表：用户手势里才申请候选地址的访问权限，失败静默沿用旧缓存 / 内置表。
endpointsRefresh.onclick = async () => {
  endpointsRefresh.disabled = true;
  const prev = endpointsRefresh.textContent;
  endpointsRefresh.textContent = '刷新中…';
  let result = null;
  try {
    result = await refreshServerEndpoints({force: true, askPermission: true});
  } catch (e) {
    result = null;
  } finally {
    endpointsRefresh.disabled = false;
    endpointsRefresh.textContent = prev;
  }
  if (!result || !result.items || !result.items.length) {
    setTest(backendTestMsg, 'bad', '✗ 未能获取云端地址列表，已沿用当前列表');
    return;
  }
  setTest(
    backendTestMsg,
    'ok',
    `✓ 云端地址列表可用（${result.items.length} 个${result.version ? '，版本 ' + result.version : ''}）`,
  );
  if (!backendPanel.hidden) renderBackendPanel();
};

/* ---------- 局域网自动发现（MV3 无裸 TCP，改 HTTP 探测 /api/health；网段前缀手输，扩展拿不到本机 IP） ---------- */

const SCAN_PORTS = [6688, 16655, 16656, 17321];
const SCAN_TIMEOUT_MS = 1200;
const SCAN_CONCURRENCY = 32;

function defaultSubnet(endpoint) {
  const m = /https?:\/\/(\d{1,3}\.\d{1,3}\.\d{1,3})\.\d{1,3}/.exec(String(endpoint || ''));
  return m ? m[1] : '192.168.10';
}

function parseSubnet(raw) {
  const v = String(raw || '').trim();
  return /^\d{1,3}(\.\d{1,3}){2}$/.test(v) && v.split('.').every((n) => +n <= 255) ? v : null;
}

// 命中判定与后端验证同口径：/api/health 返回 R 信封成功；
// 401/403 视为「可达但需配对」，可入选并在行上标注（采用时仍需 confirm）。
async function probeServer(url, timeoutMs = SCAN_TIMEOUT_MS) {
  const t0 = Date.now();
  try {
    const r = await SC.fetchWithTimeout(fetch, url + '/api/health', {headers: {Accept: 'application/json'}}, timeoutMs);
    if (r.status === 401 || r.status === 403)
      return {url, version: '', ms: Date.now() - t0, needPairing: true};
    if (!r.ok) return null;
    const data = SC.unwrapR(await r.json());
    return {url, version: (data && data.version) || '', ms: Date.now() - t0};
  } catch (e) {
    return null;
  }
}

async function ensureScanPermission() {
  const pattern = {origins: ['http://*/*']};
  let granted = false;
  try {
    granted = await chrome.permissions.contains(pattern);
  } catch (e) {
    granted = false;
  }
  if (granted) return true;
  try {
    granted = await chrome.permissions.request(pattern);
  } catch (e) {
    granted = false;
  }
  return !!granted;
}

// 现网段扫描核心：254 主机 × SCAN_PORTS 并发探活；「扫描」按钮与引导区「一键检测局域网」共用同一条链路
async function runSubnetScan(subnet, onProgress) {
  const hosts = [];
  for (let i = 1; i <= 254; i++) hosts.push(subnet + '.' + i);
  let done = 0;
  const found = [];
  for (let c = 0; c < hosts.length && !state.scanAbort; c += SCAN_CONCURRENCY) {
    const batch = hosts.slice(c, c + SCAN_CONCURRENCY);
    const hits = await Promise.all(
      batch.map(async (ip) => {
        try {
          // 多端口并探取有效命中；race 会被快速拒绝的端口以 null 抢先结算而漏报
          const hits = await Promise.all(
            SCAN_PORTS.map((p) => probeServer('http://' + ip + ':' + p, SCAN_TIMEOUT_MS)),
          );
          return hits.find(Boolean) || null;
        } finally {
          done++;
          if (onProgress) onProgress(done, found.length);
        }
      }),
    );
    for (const h of hits) if (h) found.push(h);
  }
  found.sort((a, b) => a.ms - b.ms);
  return found;
}

scanBtn.onclick = async () => {
  if (state.scanning) return;
  const subnet = parseSubnet(scanSubnet.value);
  if (!subnet) return setTest(scanMsg, 'bad', '✗ 网段前缀无效：形如 192.168.10');
  setTest(scanMsg, 'wait', '检查局域网访问授权…');
  if (!(await ensureScanPermission()))
    return setTest(scanMsg, 'bad', '✗ 未授权局域网访问，无法扫描');
  state.scanning = true;
  state.scanAbort = false;
  scanBtn.disabled = true;
  scanStop.hidden = false;
  scanResults.hidden = true;
  clearPanel(scanResults);
  try {
    const found = await runSubnetScan(subnet, (done, hits) =>
      setTest(scanMsg, 'wait', `扫描中 ${done}/254 · 已发现 ${hits} 个`),
    );
    if (state.scanAbort) {
      setTest(scanMsg, '', `已停止（发现 ${found.length} 个）`);
    } else {
      setTest(scanMsg, found.length ? 'ok' : 'bad', found.length ? `✓ 发现 ${found.length} 个可达后端` : '✗ 未发现可达后端');
    }
    if (found.length) {
      for (const f of found) {
        scanResults.appendChild(
          makeItem(f.url, (f.version ? 'v' + f.version + ' · ' : '') + f.ms + 'ms', () => applyBackend(f.url)),
        );
      }
      scanResults.hidden = false;
    }
  } finally {
    state.scanning = false;
    state.scanAbort = false;
    scanBtn.disabled = false;
    scanStop.hidden = true;
  }
};

scanStop.onclick = () => {
  state.scanAbort = true;
};

/* ---------- 打开页自动检测引导（红线：结果只呈现，写入必须经「采用 + confirm」两步，绝不自动改写地址） ---------- */

const GUIDE_PROBE_TIMEOUT_MS = 4000;
const GUIDE_SOURCE_RANK = {history: 0, registry: 1, scan: 2};
const GUIDE_SOURCE_TEXT = {history: '上次用过', registry: '预置/注册表', scan: '局域网发现'};
const GUIDE_EMPTY_TEXT =
  '当前网络未发现可达的后端服务（自动检测仅覆盖已授权的预置/历史地址），可一键检测局域网。';
const GUIDE_HIT_TEXT =
  '以下服务在你的网络中可达，点「采用」并确认后才写入，扩展不会自动改写后端地址：';

let guideMsgEl = null;

// 容器缺失守卫：node 桩环境下若未提供 #endpointGuide（既有用例）则整条引导静默跳过
function guideContainer() {
  return typeof endpointGuide === 'undefined' ? null : endpointGuide;
}

function setGuideMsg(text) {
  if (guideMsgEl) guideMsgEl.textContent = text;
}

/**
 * 合并引导候选（纯逻辑，语义对齐其余五端 mergeEndpointCandidates）：
 * source ∈ history|registry|scan，优先级 history>registry>scan，同级按 latencyMs 升序，按 origin 去重。
 */
function mergeGuideCandidates(lists) {
  const best = new Map();
  for (const [source, item] of Array.isArray(lists) ? lists : []) {
    if (!item || !(source in GUIDE_SOURCE_RANK)) continue;
    const url = normalizeEndpoint(item.url);
    if (!url) continue;
    const row = {
      url,
      label: String(item.label || url),
      source,
      needPairing: !!(item.needPairing || item.pairing),
      latencyMs: Number(item.latencyMs != null ? item.latencyMs : item.ms) || 0,
    };
    const prev = best.get(url);
    if (!prev || GUIDE_SOURCE_RANK[source] < GUIDE_SOURCE_RANK[prev.source]) best.set(url, row);
  }
  return [...best.values()].sort(
    (a, b) => GUIDE_SOURCE_RANK[a.source] - GUIDE_SOURCE_RANK[b.source] || a.latencyMs - b.latencyMs,
  );
}

function makeGuideRow(item) {
  const sub = [];
  if (item.label && item.label !== item.url) sub.push(item.label);
  sub.push(GUIDE_SOURCE_TEXT[item.source] || item.source);
  if (item.needPairing) sub.push('需配对');
  if (item.latencyMs) sub.push(item.latencyMs + 'ms');
  const row = makeItem(item.url, sub.join(' · '), () => adoptGuideCandidate(item.url));
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'adopt';
  btn.textContent = '采用';
  btn.addEventListener('click', (ev) => {
    ev.stopPropagation();
    Promise.resolve(adoptGuideCandidate(item.url)).catch(() => {});
  });
  row.appendChild(btn);
  return row;
}

// 采用两步式：confirm 确认 → 仅回填输入框并复测（落库仍需用户点「保存」）
async function adoptGuideCandidate(url) {
  const u = normalizeEndpoint(url) || url;
  if (!confirm('使用 ' + u + ' 作为后端地址？')) return false;
  hideEndpointGuide();
  await applyBackend(u);
  return true;
}

function hideEndpointGuide() {
  const g = guideContainer();
  if (!g) return;
  g.hidden = true;
  clearPanel(g);
  guideMsgEl = null;
}

/** 渲染引导容器：message 状态行 + 候选行（可空）+ 空态「一键检测局域网」+「暂不」。 */
function renderEndpointGuide(message, items) {
  const g = guideContainer();
  if (!g) return;
  clearPanel(g);
  guideMsgEl = document.createElement('p');
  guideMsgEl.className = 'hint guideMsg';
  guideMsgEl.textContent = message;
  g.appendChild(guideMsgEl);
  if (items && items.length) {
    g.appendChild(sectionTitle('检测到的候选后端'));
    for (const it of items) g.appendChild(makeGuideRow(it));
  } else {
    // 无命中/无授权：给出「一键检测局域网」按钮——点击即用户手势，才走权限申请与扫描链路
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'guideScan';
    btn.textContent = '一键检测局域网';
    btn.addEventListener('click', () => {
      Promise.resolve(guideLanScan()).catch(() => {});
    });
    g.appendChild(btn);
  }
  const dismiss = document.createElement('button');
  dismiss.type = 'button';
  dismiss.className = 'guideDismiss';
  dismiss.textContent = '暂不';
  dismiss.title = '本次会话不再自动弹出';
  dismiss.addEventListener('click', () => {
    state.guideDismissed = true;
    hideEndpointGuide();
  });
  g.appendChild(dismiss);
  g.hidden = false;
}

/**
 * 初始化自动检测：对 (presetList() ∪ 历史) ∩ 已授权 origin 并发 probeServer（4s）。
 * 命中 → 渲染候选行；零命中/无授权 → 「未发现/一键检测」提示。全程不写 storage、不申请权限。
 */
async function autoGuideBackend() {
  if (state.guideDismissed) return;
  if (!guideContainer()) return;
  const bases = [];
  const push = (raw) => {
    const url = normalizeEndpoint(typeof raw === 'string' ? raw : raw && raw.url);
    if (url && bases.indexOf(url) < 0) bases.push(url);
  };
  for (const p of presetList()) push(p);
  for (const h of state.backendHistory) push(h);
  const current = normalizeEndpoint(backendEndpoint.value);
  const targets = (await grantedBases(bases)).filter((b) => b !== current);
  const lists = [];
  if (targets.length) {
    const probed = await Promise.all(targets.map((b) => probeServer(b, GUIDE_PROBE_TIMEOUT_MS)));
    probed.forEach((hit, i) => {
      if (!hit) return;
      const url = targets[i];
      const fromHistory = state.backendHistory.some((h) => normalizeEndpoint(h) === url);
      const preset = presetList().find((p) => normalizeEndpoint(p.url) === url);
      lists.push([
        fromHistory ? 'history' : 'registry',
        {
          url,
          label: fromHistory ? url : preset ? preset.label : url,
          needPairing: !!hit.needPairing || !!(preset && preset.pairing),
          latencyMs: hit.ms,
        },
      ]);
    });
  }
  const merged = mergeGuideCandidates(lists);
  renderEndpointGuide(merged.length ? GUIDE_HIT_TEXT : GUIDE_EMPTY_TEXT, merged);
}

// 引导区内的一键局域网检测：仅在用户点击手势内 ensureScanPermission + 现网段扫描；结果仍只经 confirm 采用
async function guideLanScan() {
  if (state.scanning) return;
  const g = guideContainer();
  if (!g) return;
  const subnet = parseSubnet(scanSubnet.value) || defaultSubnet(backendEndpoint.value);
  setGuideMsg('检查局域网访问授权（网段 ' + subnet + '.x）…');
  if (!(await ensureScanPermission())) {
    setGuideMsg('✗ 未授权局域网访问，无法扫描（授权只在点击后申请）');
    return;
  }
  state.scanning = true;
  state.scanAbort = false;
  try {
    const found = await runSubnetScan(subnet, (done, hits) =>
      setGuideMsg('扫描中 ' + done + '/254 · 已发现 ' + hits + ' 个'),
    );
    if (!found.length) {
      renderEndpointGuide('✗ 未发现可达后端（网段 ' + subnet + '.x），可在下方局域网区修改网段前缀后重试。', []);
      return;
    }
    renderEndpointGuide(
      GUIDE_HIT_TEXT,
      mergeGuideCandidates(
        found.map((f) => [
          'scan',
          {url: f.url, label: f.version ? 'v' + f.version : f.url, needPairing: !!f.needPairing, latencyMs: f.ms},
        ]),
      ),
    );
  } finally {
    state.scanning = false;
    state.scanAbort = false;
  }
}

/* ---------- 页面入口（Web / H5 / APP 下载页 / 下载中心） ---------- */

// 解析纯逻辑（含蒲公英短链与留空现算规则）在 entry-urls.js，与弹窗共用
const APP_ANDROID_URL = EU.APP_ANDROID_URL;
const cleanEntryUrl = EU.cleanEntryUrl;
// 前端页面命中判定用的常见前端端口候选：与弹窗的入口可信判定同源（entry-urls.js）
const ENTRY_PROBE_WEB_PORTS = EU.WEB_ROOT_PORTS;
const ENTRY_PROBE_H5_PORT = '7790';
const ENTRY_PROBE_TIMEOUT_MS = 3000;

// 入口框留空时按占位规则现算：Web ← 后端地址；H5 / 下载中心 ← Web；APP ← 蒲公英固定短链。
function readEntryFields() {
  return {
    webEntryUrl: webEntryUrl.value,
    h5EntryUrl: h5EntryUrl.value,
    downloadEntryUrl: downloadEntryUrl.value,
    appEntryUrl: appEntryUrl.value,
    backendEndpoint: backendEndpoint.value,
  };
}

function resolveEntryUrl(kind) {
  return EU.resolveEntry(kind, readEntryFields());
}

function openEntryUrl(url) {
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({url});
    return;
  }
  window.open(url, '_blank');
}

function bindOpenBtn(btn, kind) {
  btn.onclick = () => {
    const url = resolveEntryUrl(kind);
    if (!url) {
      setTest(entriesMsg, 'bad', '✗ 该入口未配置，且无法从后端地址现算，请先填写或点「探测入口地址」');
      return;
    }
    setTest(entriesMsg, 'ok', '✓ 已打开 ' + url);
    openEntryUrl(url);
  };
}

bindOpenBtn(openWeb, 'web');
bindOpenBtn(openH5, 'h5');
bindOpenBtn(openApp, 'app');
bindOpenBtn(openDownload, 'download');

entriesFill.onclick = () => {
  const backend = normalizeEndpoint(backendEndpoint.value);
  if (!backend) return setTest(entriesMsg, 'bad', '✗ 请先填写有效的后端地址');
  webEntryUrl.value = backend;
  h5EntryUrl.value = backend + '/h5/';
  downloadEntryUrl.value = backend + '/download';
  if (!appEntryUrl.value) appEntryUrl.value = APP_ANDROID_URL;
  setTest(entriesMsg, 'ok', '✓ 已按后端地址生成入口，可修改后保存');
};

// 前端页面命中判定：200 + HTML 标记开头 + 含 SPA 挂载点（Vite 壳的 id="app"）。
// 后端直连口自带引导页（纯 HTML、无挂载点），只按 doctype 判会误报，故要求挂载点特征。
// 调用方须传完整 URL（含结尾斜杠），fetchWithTimeout 不做归一。
async function probeHtml(url) {
  try {
    const r = await SC.fetchWithTimeout(fetch, url, {headers: {Accept: 'text/html'}}, ENTRY_PROBE_TIMEOUT_MS);
    if (!r.ok) return false;
    const body = String((await r.text().catch(() => '')) || '').slice(0, 4096);
    return /^\s*<(?:!doctype|html)/i.test(body) && /id=["']app["']/.test(body);
  } catch (e) {
    return false;
  }
}

function entryProbeCandidates() {
  const backend = normalizeEndpoint(backendEndpoint.value);
  if (!backend) return [];
  const u = new URL(backend);
  const scheme = u.protocol.replace(':', '');
  const seen = [];
  for (const port of [u.port || (scheme === 'https' ? '443' : '80'), ...ENTRY_PROBE_WEB_PORTS]) {
    const root = scheme + '://' + u.hostname + (port ? ':' + port : '');
    if (seen.indexOf(root) < 0) seen.push(root);
  }
  return seen;
}

// H5 双形态：网关聚合部署走 Web 根下的 /h5/，NAS 分离部署走同主机独立端口，探不到仍按 /h5/ 回填。
async function detectH5Root(web) {
  if (await probeHtml(web + '/h5/')) return web + '/h5/';
  const u = new URL(web);
  const alt = u.protocol + '//' + u.hostname + ':' + ENTRY_PROBE_H5_PORT + '/';
  if (await probeHtml(alt)) return alt;
  return web + '/h5/';
}

entriesDetect.onclick = async () => {
  const candidates = entryProbeCandidates();
  if (!candidates.length) return setTest(entriesMsg, 'bad', '✗ 未填写后端地址，无法探测');
  entriesDetect.disabled = true;
  try {
    setTest(entriesMsg, 'wait', '申请权限并探测前端端口…');
    const granted = await requestBases(candidates);
    if (!granted.length) return setTest(entriesMsg, 'bad', '✗ 未获得候选地址访问权限，探测中止');
    const hits = await Promise.all(granted.map((c) => probeHtml(c + '/').then((ok) => (ok ? c : null))));
    const web = hits.find(Boolean);
    if (!web) {
      return setTest(entriesMsg, 'bad', '✗ 未探测到 Web 前端（' + granted.join(' / ') + '），可手动填写后用「打开」');
    }
    webEntryUrl.value = web;
    h5EntryUrl.value = await detectH5Root(web);
    downloadEntryUrl.value = web + '/download';
    if (!appEntryUrl.value) appEntryUrl.value = APP_ANDROID_URL;
    setTest(entriesMsg, 'ok', '✓ 探测到 Web 入口 ' + web + '，已回填，可保存');
  } finally {
    entriesDetect.disabled = false;
  }
};

/* ---------- 保存 ---------- */

save.onclick = async () => {
  const endpoint = normalizeEndpoint(backendEndpoint.value);
  if (endpoint === null) {
    msg.textContent = ' 后端地址无效：需为 http/https URL';
    return;
  }
  if (!['auto', 'backend', 'desktop'].includes(syncChannelMode.value)) {
    msg.textContent = ' 同步通道取值无效';
    return;
  }
  const entryInputs = {
    webEntryUrl: webEntryUrl.value,
    h5EntryUrl: h5EntryUrl.value,
    appEntryUrl: appEntryUrl.value,
    downloadEntryUrl: downloadEntryUrl.value,
  };
  const entryValues = {};
  for (const k of Object.keys(entryInputs)) {
    const raw = String(entryInputs[k] || '').trim();
    if (raw && !cleanEntryUrl(raw)) {
      msg.textContent = ' 入口地址无效（需 http/https URL）：' + k;
      return;
    }
    entryValues[k] = cleanEntryUrl(raw);
  }
  // 后端地址变更时申请 host 权限（optional_host_permissions），拒绝则中止保存
  const current = await new Promise((res) =>
    chrome.storage.local.get({backendEndpoint: ''}, (s) => res(s.backendEndpoint))
  );
  if (endpoint && endpoint !== current) {
    let granted = false;
    try {
      granted = await chrome.permissions.request({origins: [endpoint + '/*']});
    } catch (e) {
      granted = false;
    }
    if (!granted) {
      msg.textContent = ' 未获得后端地址访问权限，已取消保存';
      return;
    }
  }
  await chrome.storage.local.set({
    baseUrl: baseUrl.value.replace(/\/+$/, ''),
    token: token.value,
    autoSync: autoSync.checked,
    enabled: floatEnabled.checked,
    wechatEnabled: wechatEnabled.checked,
    syncChannelMode: syncChannelMode.value,
    backendEndpoint: endpoint,
    backendToken: String(backendToken.value || '').trim(),
    preferLargeImage: preferLargeImage.checked,
    ...entryValues,
  });
  msg.textContent = ' 已保存';
  setTimeout(() => (msg.textContent = ''), 1500);
};

// 测试钩子：node 桩环境驱动验证历史入档/扫描流程/服务地址注册表
self.__downxOptions = {
  state,
  applyBackend,
  applyDesktop,
  renderBackendPanel,
  renderDesktopPanel,
  parseSubnet,
  defaultSubnet,
  probeServer,
  presetList,
  presetSignature,
  endpointCandidateBases,
  fetchServerEndpoints,
  refreshServerEndpoints,
  // 自动检测引导：纯合并逻辑 + 引导入口（ready 供测试 await 初始化链路）
  ready,
  mergeGuideCandidates,
  autoGuideBackend,
  guideLanScan,
  // 页面入口：解析/探测纯逻辑
  APP_ANDROID_URL,
  cleanEntryUrl,
  resolveEntryUrl,
  entryProbeCandidates,
  probeHtml,
  detectH5Root,
};
