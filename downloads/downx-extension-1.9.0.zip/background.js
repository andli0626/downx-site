// background.js · MV3 service worker
// 三通道保存编排：后端直连（提取+JSON 同步+媒体上传）→ 桌面桥接（URL 提交，零改动复用）
// → 浏览器下载目录兜底；后端不可用时整单入 outbox 待补推。
// 依赖：sync-channel.js / outbox.js / md-builder.js（SW 经 importScripts 加载；测试环境由加载器预置到 self）。
if (typeof importScripts === 'function') {
  importScripts('sync-channel.js', 'outbox.js', 'md-builder.js');
}
const SC = self.DownXSyncChannel;
const OB = self.DownXOutbox;

const DEFAULTS = {
  baseUrl: 'http://127.0.0.1:17321',
  token: '',
  autoSync: true,
  enabled: true,
  wechatEnabled: false, // 站点级：默认只认 X 文章，公众号要用户在设置页显式开启
  syncChannelMode: 'auto', // auto | backend | desktop
  backendEndpoint: '',
  backendToken: '',
  saveLocation: 'DownX', // 浏览器下载目录下的子目录（download 通道）
  preferLargeImage: true, // 归档图片 small/medium 归一为 large，提升保真度
};

// 单文件上传/下载超时；ExportJob 心跳陈旧阈值 = 2×
const MEDIA_TIMEOUT_MS = 120000;
const JOB_STALE_MS = 2 * MEDIA_TIMEOUT_MS;
const UPLOAD_RETRIES = 2;
const MEDIA_FETCH_RETRIES = 4;
const DOWNLOAD_CONCURRENCY = 4;
const DESKTOP_PROBE_TIMEOUT_MS = 1500;

let currentJob = null; // {tabId, key, startedAt, heartbeatAt}

/* ---------- 基础设施 ---------- */

function clientVersion() {
  try {
    return chrome.runtime.getManifest().version;
  } catch (e) {
    // 仅在非扩展环境（预览/测试 harness）走到这里；改扩展版本时同步此兜底值（缺陷 D-04）
    return '1.9.0';
  }
}

async function getSettings() {
  const o = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const s = Object.assign({}, DEFAULTS, o);
  return s;
}

async function ensureDeviceId() {
  const o = await chrome.storage.local.get('deviceId');
  if (o && o.deviceId) return o.deviceId;
  let id = 'ext-';
  try {
    id += crypto.randomUUID().replace(/-/g, '').slice(0, 16);
  } catch (e) {
    id += String(Date.now()) + '-' + Math.floor(Math.random() * 1e8);
  }
  await chrome.storage.local.set({deviceId: id});
  return id;
}

function uuid() {
  try {
    return crypto.randomUUID();
  } catch (e) {
    return 'u-' + Date.now() + '-' + Math.floor(Math.random() * 1e8);
  }
}

function notify(nid, title, message) {
  try {
    chrome.notifications.create(nid, {
      type: 'basic',
      iconUrl: 'icons/icon-128.png',
      title,
      message,
    });
  } catch (e) {
    /* 通知失败不影响主流程 */
  }
}

function broadcast(tabId, state) {
  try {
    const p = chrome.tabs.sendMessage(tabId, {type: 'EXPORT_STATE', state});
    if (p && p.catch) p.catch(() => {});
  } catch (e) {
    /* 页面已关闭等情况 */
  }
}

/* ---------- 桌面桥接（沿用原有端点与响应形状） ---------- */

function api(settings, path, body, method) {
  const headers = {Accept: 'application/json'};
  if (settings.token) headers.Authorization = 'Bearer ' + settings.token;
  return fetch(settings.baseUrl.replace(/\/+$/, '') + path, {
    method: method || (body ? 'POST' : 'GET'),
    headers: body ? Object.assign(headers, {'Content-Type': 'application/json'}) : headers,
    body: body ? JSON.stringify(body) : undefined,
  }).then((r) => (r.status === 204 ? null : r.json()), (e) => {
    // 网络层失败（客户端没开/端口不通）：归类 offline，与旧版 fail(..., 'offline') 契约一致；
    // floating 的 isOffline 对原始响应只认 code（message 正则只覆盖 apiFailure 包装后的路径）。
    const err = new Error((e && e.message) || 'Failed to fetch');
    err.code = 'offline';
    throw err;
  });
}

// 桌面探活：缓存 15s，避免每次保存都打桥接
let desktopProbeCache = {at: 0, ok: false};
// UI_PROBE 专用后端探活门：floating 每 5s 心跳问一次通道，TTL（默认 30s）内复用缓存结果；
// 换端点自动失效（gate 内部按 endpoint 键控）。runSave 仍用各自的 fresh gate，保存选路不受此缓存影响。
const probeGate = SC.makeBackendGate();
async function probeDesktop(settings, nowMs) {
  const now = nowMs == null ? Date.now() : nowMs;
  if (now - desktopProbeCache.at < 15000) return desktopProbeCache.ok;
  let ok = false;
  try {
    const r = await SC.fetchWithTimeout(fetch, settings.baseUrl.replace(/\/+$/, '') + '/health', {}, DESKTOP_PROBE_TIMEOUT_MS);
    ok = !!r && r.ok;
  } catch (e) {
    ok = false;
  }
  desktopProbeCache = {at: now, ok};
  return ok;
}

/* ---------- 通道选择 ---------- */

async function resolveSyncChannel(settings, backendGate) {
  const hasEndpoint = !!settings.backendEndpoint;
  let backendOk = false;
  if (hasEndpoint) backendOk = (await backendGate.check(settings.backendEndpoint)).ok;
  let desktopOk = false;
  // 仅在可能走桌面通道时才探活（backend 已命中 / 锁定 backend 且失败时不必探）
  const channelProbe = SC.resolveChannel({
    mode: settings.syncChannelMode,
    hasEndpoint,
    backendOk,
    desktopOk: true,
  });
  if (channelProbe === 'desktop' || channelProbe === 'download') {
    desktopOk = await probeDesktop(settings);
  }
  return {
    channel: SC.resolveChannel({mode: settings.syncChannelMode, hasEndpoint, backendOk, desktopOk}),
    backendOk,
    desktopOk,
  };
}

/* ---------- ExportJob 互斥（storage.session + 内存双标记，TTL 内拒绝并发） ---------- */

async function tryAcquireJob(tabId, key) {
  const now = Date.now();
  if (currentJob && now - currentJob.heartbeatAt < JOB_STALE_MS) return false;
  let prev = null;
  try {
    const o = await chrome.storage.session.get('exportJob');
    prev = o && o.exportJob;
  } catch (e) {
    /* storage.session 不可用时仅靠内存锁 */
  }
  if (prev && now - prev.heartbeatAt < JOB_STALE_MS && !(currentJob && currentJob.key === prev.key)) return false;
  currentJob = {tabId, key, startedAt: now, heartbeatAt: now};
  try {
    await chrome.storage.session.set({exportJob: currentJob});
  } catch (e) {
    /* 同上 */
  }
  return true;
}

async function heartbeat() {
  if (!currentJob) return;
  currentJob.heartbeatAt = Date.now();
  try {
    await chrome.storage.session.set({exportJob: currentJob});
  } catch (e) {
    /* 同上 */
  }
}

async function releaseJob() {
  currentJob = null;
  try {
    await chrome.storage.session.remove('exportJob');
  } catch (e) {
    /* 同上 */
  }
}

/* ---------- outbox 冲刷：后端恢复即补推历史（仅 JSON，媒体二进制不入队） ---------- */

async function flushOutbox(settings, backendGate, deviceId) {
  const outbox = OB.createOutbox(chrome.storage.local);
  const entries = await outbox.readAll();
  if (!entries.length || !settings.backendEndpoint) return {pushed: 0, remaining: entries.length};
  const backendOk = (await backendGate.check(settings.backendEndpoint)).ok;
  if (!backendOk) return {pushed: 0, remaining: entries.length};
  let pushed = 0;
  // 跨端删除感知：已删文章不再补推（旧包 fetched_at 新于 deleted_at 会复活墓碑，
  // 造成多端文章数"凭空 +1"）。拉取失败（null）按未知处理，维持原补推行为。
  const tombstoned = await SC.fetchTombstoneIds(settings.backendEndpoint, {token: settings.backendToken});
  for (const entry of entries) {
    try {
      if (tombstoned && tombstoned[entry.bundle.id]) {
        await outbox.remove(entry.key);
        notify(
          'outbox-deleted-' + entry.key,
          '文章已删除，跳过补推',
          '「' + (entry.bundle.title || entry.key) + '」已在服务端删除，本次不再补推。',
        );
        continue;
      }
      await SC.pushBundles(settings.backendEndpoint, entry.bundle, deviceId, clientVersion(), {token: settings.backendToken});
      pushed++;
      const complete = OB.mediaComplete(entry);
      await outbox.remove(entry.key);
      if (!complete) {
        notify(
          'outbox-media-' + entry.key,
          '文章已补推，媒体有缺口',
          '「' + (entry.bundle.title || entry.key) + '」正文已同步，' +
            OB.pendingMediaNames(entry).length + ' 个媒体缺失，可重新打开该文章再保存一次补齐。',
        );
      }
    } catch (e) {
      if (e && e.kind === 'unavailable') break; // 后端又挂了：保留剩余条目
      entry.attempts = (entry.attempts || 0) + 1;
      entry.lastError = (e && e.message) || String(e);
      await outbox.upsert(entry); // business 错误：记 attempts 后保留
    }
  }
  return {pushed, remaining: (await outbox.readAll()).length};
}

/* ---------- backend 通道：两阶段推送（建行+媒体上传+终态正文） ---------- */

async function fetchMediaBlob(url) {
  const r = await SC.fetchWithTimeout(fetch, url, {mode: 'cors'}, MEDIA_TIMEOUT_MS);
  if (!r.ok) throw new Error('媒体下载失败 HTTP ' + r.status);
  return r.blob();
}

// 图床到本机的 TLS 握手会被间歇性掐断（连续两次立刻失败、第三次就通了），所以重试之间
// 必须留间隔：紧挨着的三次基本同时失败，媒体最后定格成 missing，文章永远记 partial。
async function withRetries(fn, times, baseDelayMs) {
  const base = baseDelayMs || 600;
  let lastErr = null;
  for (let i = 0; i <= times; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      if (i < times) await new Promise((r) => setTimeout(r, Math.min(base << i, 6000)));
    }
  }
  throw lastErr;
}

async function runSaveViaBackend(tabId, snapshot, settings, deviceId, backendGate) {
  const endpoint = settings.backendEndpoint;
  const bundle = SC.buildBundle(snapshot, {sourceTaskId: 'ext-' + deviceId});
  broadcast(tabId, {phase: 'pushing', message: '同步文章到后端…'});

  // push#1：建文章行 + 媒体元数据（Media 行 sortNo = media 下标）
  try {
    await SC.pushBundles(endpoint, bundle, deviceId, clientVersion(), {token: settings.backendToken});
  } catch (e) {
    if (e.kind === 'unavailable') throw e; // 整单入 outbox（由调用方处理）
    throw e; // business/auth：明确失败（不入 outbox，重试无意义）
  }

  // 媒体上传：非 streamOnly 逐个 fetch + multipart 上传（重试 2 次）
  const shareUuid = uuid();
  const mediaStates = new Array(snapshot.media.length).fill(null);
  let unavailableHit = null;
  for (let i = 0; i < snapshot.media.length; i++) {
    const m = snapshot.media[i];
    if (m.streamOnly || !m.url) {
      mediaStates[i] = {status: 'skipped'};
      continue;
    }
    await heartbeat();
    broadcast(tabId, {phase: 'uploading', message: '上传媒体 ' + (i + 1) + '/' + snapshot.media.length + '…'});
    try {
      const blob = await withRetries(() => fetchMediaBlob(m.url), MEDIA_FETCH_RETRIES);
      const up = await withRetries(
        () =>
          SC.uploadArticleMedia(
            endpoint,
            bundle.id,
            shareUuid,
            i,
            blob,
            {
              filename: self.DownXMdBuilder ? self.DownXMdBuilder.mediaFilename(m, i) : i + '_media',
              mediaType: m.media_type,
              originalUrl: m.url,
              description: m.description || '',
              width: m.width,
              height: m.height,
              duration: m.duration,
              device: deviceId,
            },
            {timeoutMs: MEDIA_TIMEOUT_MS, token: settings.backendToken},
          ),
        UPLOAD_RETRIES,
      );
      mediaStates[i] = {status: 'ok', url: up.url};
    } catch (e) {
      if (e && e.kind === 'unavailable') {
        unavailableHit = e; // 后端失联：立即停止，整单入 outbox
        break;
      }
      mediaStates[i] = {status: 'missing', error: (e && e.message) || String(e)}; // 单文件定格失败
    }
  }
  if (unavailableHit) throw unavailableHit;

  // BUILD_MD：已上传媒体注入 /api/media/ 终态 URL；缺失/streamOnly 回退原始 URL
  const mediaUrls = snapshot.media.map((m, i) => (mediaStates[i] && mediaStates[i].url) || m.url);
  let markdown = '';
  try {
    const r = await chrome.tabs.sendMessage(tabId, {type: 'BUILD_MD', snapshot, mediaUrls});
    markdown = (r && r.markdown) || '';
  } catch (e) {
    /* 页面已关：不阻断，正文缺 markdown 终态 */
  }
  if (!markdown && self.DownXMdBuilder) markdown = self.DownXMdBuilder.buildMarkdown(snapshot, {mediaUrls});
  // 前端详情默认渲染 HTML 页签：必须与 markdown 同步回填终态 html
  let html = '';
  try {
    if (self.DownXMdBuilder) html = self.DownXMdBuilder.buildHtml(snapshot, {mediaUrls}) || '';
  } catch (e) {
    /* html 缺失不阻断，markdown 仍在 */
  }

  // push#2：终态 markdown + 完整性
  const finalBundle = SC.buildBundle(snapshot, {sourceTaskId: 'ext-' + deviceId, mediaMeta: mediaStates});
  finalBundle.markdown = markdown;
  finalBundle.html = html;
  await SC.pushBundles(endpoint, finalBundle, deviceId, clientVersion(), {token: settings.backendToken});
  return {channel: 'backend', bundle: finalBundle, mediaStates};
}

/* ---------- desktop 通道：沿用既有桥接（桌面 CDP 抓取 + 自行同步后端） ---------- */

async function runSaveViaDesktop(tabId, snapshot, settings) {
  broadcast(tabId, {phase: 'desktop', message: '已提交桌面端 DownX 抓取…'});
  const body = {
    type: 'download',
    url: snapshot.original_url,
    downloadImages: true,
    downloadVideos: true,
    autoSync: settings.autoSync,
    source: 'browser-extension',
  };
  const data = await api(settings, '/api/download', body);
  if (!data || !data.taskId) throw new Error('桌面端未返回任务 ID');
  return {channel: 'desktop', taskId: data.taskId};
}

/* 公众号通道：扩展不做页面提取（微信正文要滚动唤醒懒加载、还要过反爬判定），
   只递交网址，桌面端 /api/download 会自行规范化网址并按主键判重。 */
async function runSaveViaWechatBridge(url, settings) {
  const body = {
    type: 'download',
    url,
    downloadImages: true,
    downloadVideos: true,
    autoSync: settings.autoSync,
    source: 'browser-extension',
  };
  const data = await api(settings, '/api/download', body);
  if (data && data.status === 'duplicate') return {channel: 'duplicate', articleId: data.articleId};
  if (!data || !data.taskId) throw new Error((data && data.error) || '桌面端未返回任务 ID');
  return {channel: 'desktop', taskId: data.taskId};
}

// SAVE_WECHAT 的处理体（独立成函数：单测打这里进，不必伪造 onMessage 监听）。
async function saveWechat(rawUrl, settings) {
  const url = String(rawUrl || '').trim();
  let target = null;
  try {
    target = new URL(url);
  } catch (e) {
    target = null;
  }
  // 网址自己复核一遍：content script 可能被页面诱导，递交非微信图文网址只会让桌面端白跑一趟。
  if (!target || target.protocol !== 'https:' || target.hostname !== 'mp.weixin.qq.com') {
    return {ok: false, error: '这不是微信公众号文章页'};
  }
  if (!settings.enabled) return {ok: false, error: '悬浮按钮已停用'};
  // 站点开关在后台再判一次：快捷键 Alt+Shift+S 递来的 SAVE_WECHAT 不经悬浮钮，只靠 content 层门禁会漏。
  if (!settings.wechatEnabled) {
    return {ok: false, code: 'wechat-disabled', error: '微信文章下载未开启，请在扩展设置页勾选「支持微信公众号图文下载」'};
  }
  try {
    const r = await runSaveViaWechatBridge(url, settings);
    return r.channel === 'duplicate' ? {ok: true, channel: 'duplicate', articleId: r.articleId} : {ok: true, channel: 'desktop', taskId: r.taskId};
  } catch (e) {
    const code = e && e.code;
    // 公众号没有兜底通道（扩展抓不到微信正文），离线要说清依赖而不是泛指的「保存失败」
    return {
      ok: false,
      code: code,
      error: code === 'offline' ? '公众号文章需要桌面端 DownX 在线抓取，请启动客户端' : (e && e.message) || '提交失败',
    };
  }
}

/* ---------- download 通道：浏览器下载目录兜底 ---------- */

function waitDownload(downloadId, timeoutMs) {
  return new Promise((resolve) => {
    const started = Date.now();
    const timer = setInterval(async () => {
      let items = [];
      try {
        items = await chrome.downloads.search({id: downloadId});
      } catch (e) {
        /* 查询失败按超时处理 */
      }
      const d = items && items[0];
      if (d && d.state === 'complete') {
        clearInterval(timer);
        resolve({ok: true});
      } else if (d && d.state === 'interrupted') {
        clearInterval(timer);
        resolve({ok: false, error: d.error || 'interrupted'});
      } else if (Date.now() - started > timeoutMs) {
        clearInterval(timer);
        try {
          await chrome.downloads.cancel(downloadId);
        } catch (e) {
          /* 已结束的下载无需取消 */
        }
        resolve({ok: false, error: 'timeout'});
      }
    }, 500);
  });
}

function safeName(s) {
  return String(s || '').replace(/[\\/:*?"<>|\n\r\t]+/g, '_').replace(/^\.+/, '').slice(0, 80) || 'article';
}

async function runSaveViaDownloads(tabId, snapshot, settings) {
  const key = SC.articleKey(snapshot.original_url);
  const dir = (settings.saveLocation || 'DownX') + '/' + safeName(snapshot.title) + '_' + key;
  const mediaStates = new Array(snapshot.media.length).fill(null);
  let failed = 0;

  const queue = [];
  snapshot.media.forEach((m, i) => {
    if (m.streamOnly || !m.url) {
      mediaStates[i] = {status: 'skipped'};
      return;
    }
    queue.push({m, i});
  });

  let cursor = 0;
  const worker = async () => {
    while (cursor < queue.length) {
      const {m, i} = queue[cursor++];
      await heartbeat();
      const filename = dir + '/media/' + (self.DownXMdBuilder ? self.DownXMdBuilder.mediaFilename(m, i) : i + '_media');
      try {
        const id = await chrome.downloads.download({url: m.url, filename, conflictAction: 'uniquify', saveAs: false});
        const r = await waitDownload(id, MEDIA_TIMEOUT_MS);
        if (!r.ok) throw new Error(r.error || 'download failed');
        mediaStates[i] = {status: 'ok', url: 'media/' + (self.DownXMdBuilder ? self.DownXMdBuilder.mediaFilename(m, i) : i + '_media')};
      } catch (e) {
        failed++;
        mediaStates[i] = {status: 'missing', error: (e && e.message) || String(e)};
      }
    }
  };
  await Promise.all(Array.from({length: Math.min(DOWNLOAD_CONCURRENCY, queue.length || 1)}, worker));

  const mediaUrls = snapshot.media.map((m, i) => (mediaStates[i] && mediaStates[i].url) || m.url);
  let markdown = '';
  try {
    const r = await chrome.tabs.sendMessage(tabId, {type: 'BUILD_MD', snapshot, mediaUrls});
    markdown = (r && r.markdown) || '';
  } catch (e) {
    /* 页面已关 */
  }
  if (!markdown && self.DownXMdBuilder) markdown = self.DownXMdBuilder.buildMarkdown(snapshot, {mediaUrls});

  const mdUrl = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(markdown);
  await chrome.downloads.download({
    url: mdUrl,
    filename: dir + '/' + key + '.md',
    conflictAction: 'uniquify',
    saveAs: false,
  });
  return {channel: 'download', mediaStates, failed};
}

/* ---------- 主入口 ---------- */

async function runSave(tabId) {
  const settings = await getSettings();
  if (!settings.enabled) return {ok: false, error: '悬浮按钮已停用'};
  const deviceId = await ensureDeviceId();
  const backendGate = SC.makeBackendGate();

  // 旁路冲刷 outbox：失败不影响本次保存
  flushOutbox(settings, backendGate, deviceId).catch(() => {});

  broadcast(tabId, {phase: 'extracting', message: '提取页面内容…'});
  let snapshot = null;
  try {
    const r = await chrome.tabs.sendMessage(tabId, {type: 'EXTRACT_REQUEST', options: {preferLargeImage: settings.preferLargeImage !== false}});
    if (!r || !r.ok || !r.snapshot) return {ok: false, error: (r && r.error) || '页面内容提取失败'};
    snapshot = r.snapshot;
  } catch (e) {
    return {ok: false, error: '无法与页面通信，请刷新后重试'};
  }
  const key = SC.articleKey(snapshot.original_url);
  if (!key) return {ok: false, error: '当前页面不是可保存的文章'};

  if (!(await tryAcquireJob(tabId, key))) return {ok: false, error: '已有保存任务进行中，请稍候'};
  try {
    const {channel, backendOk, desktopOk} = await resolveSyncChannel(settings, backendGate);
    if (channel === 'backend') {
      try {
        const r = await runSaveViaBackend(tabId, snapshot, settings, deviceId, backendGate);
        const missing = r.mediaStates.filter((s) => s && s.status === 'missing').length;
        broadcast(tabId, {phase: 'done', channel: 'backend', message: '已同步到后端'});
        notify('save-' + key, '文章已同步', '「' + (snapshot.title || key) + '」已推送到后端' + (missing ? '（' + missing + ' 个媒体缺失）' : ''));
        return {ok: true, channel: 'backend'};
      } catch (e) {
        if (e && e.kind === 'unavailable') {
          // 后端失联：整单入 outbox（含已上传媒体状态），恢复后补推
          const bundle = SC.buildBundle(snapshot, {sourceTaskId: 'ext-' + deviceId});
          let markdown = '';
          try {
            const r = await chrome.tabs.sendMessage(tabId, {type: 'BUILD_MD', snapshot, mediaUrls: snapshot.media.map((m) => m.url)});
            markdown = (r && r.markdown) || '';
          } catch (e2) {
            /* 页面已关 */
          }
          if (markdown) bundle.markdown = markdown;
          try {
            if (self.DownXMdBuilder) {
              const h = self.DownXMdBuilder.buildHtml(snapshot, {mediaUrls: snapshot.media.map((m) => m.url)});
              if (h) bundle.html = h;
            }
          } catch (e3) {
            /* 忽略 */
          }
          const outbox = OB.createOutbox(chrome.storage.local);
          await outbox.upsert(OB.entryFromBundle(bundle, [], e.message));
          broadcast(tabId, {phase: 'queued', message: '后端暂不可达，已加入待同步队列'});
          notify('queued-' + key, '已加入待同步队列', '「' + (snapshot.title || key) + '」将在后端恢复后自动补推。');
          return {ok: true, channel: 'queued'};
        }
        broadcast(tabId, {phase: 'error', message: e.message || '同步失败'});
        return {ok: false, error: e.message || '同步失败'};
      }
    }
    if (channel === 'desktop') {
      const r = await runSaveViaDesktop(tabId, snapshot, settings);
      broadcast(tabId, {phase: 'desktop', taskId: r.taskId, message: '桌面端抓取中…'});
      return {ok: true, channel: 'desktop', taskId: r.taskId};
    }
    if (channel === 'download') {
      const r = await runSaveViaDownloads(tabId, snapshot, settings);
      broadcast(tabId, {phase: 'done', channel: 'download', message: '已保存到下载目录'});
      notify(
        'save-' + key,
        '文章已保存到下载目录',
        '「' + (snapshot.title || key) + '」已保存至 ' + (settings.saveLocation || 'DownX') + '/' + safeName(snapshot.title) + '_' + key +
          (r.failed ? '（' + r.failed + ' 个媒体下载失败）' : ''),
      );
      return {ok: true, channel: 'download'};
    }
    // error 通道：锁定 backend 但不可达
    broadcast(tabId, {phase: 'error', message: '后端不可达（通道已锁定为仅后端）'});
    return {ok: false, error: '后端不可达：请检查后端服务地址，或将同步通道切换为"自动"'};
  } finally {
    await releaseJob();
  }
}

/* ---------- 消息路由 ---------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const p = (async () => {
    const settings = await getSettings();
    switch (msg && msg.type) {
      // —— 原有桌面桥接中继（任务面板等，保持兼容）——
      // 桥接端点本身是裸 JSON（bridge_compat.rs 契约），对 content/popup 统一包 {ok,data} 信封；
      // 失败走外层 catch → {ok:false,error,code?}：网络层失败带 code:'offline'（floating 的 isOffline 只认原始响应的 code）。
      case 'health':
        try {
          return {online: true, data: await api(settings, '/health')};
        } catch (e) {
          return {online: false};
        }
      case 'download':
        return {ok: true, data: await api(settings, '/api/download', msg)};
      case 'task':
        return {ok: true, data: await api(settings, '/api/tasks/' + encodeURIComponent(msg.taskId))};
      case 'recent':
        return {ok: true, data: await api(settings, '/api/tasks/recent')};
      case 'retry':
        return {ok: true, data: await api(settings, '/api/tasks/' + encodeURIComponent(msg.taskId) + '/retry', {})};
      case 'deleteTask':
        return {ok: true, data: await api(settings, '/api/tasks/' + encodeURIComponent(msg.taskId), null, 'DELETE')};
      case 'clearFinished':
        return {ok: true, data: await api(settings, '/api/tasks/clear-finished', {})};
      // —— 新增：独立保存 + 状态探测 ——
      case 'SAVE_START': {
        const tabId = (msg.tabId != null ? msg.tabId : sender && sender.tab && sender.tab.id);
        if (tabId == null) return {ok: false, error: '缺少目标标签页'};
        return runSave(tabId);
      }
      case 'SAVE_WECHAT':
        return saveWechat(msg.url, settings);
      case 'UI_PROBE': {
        const backendGate = probeGate; // TTL 缓存：悬浮钮心跳高频，不能让每次探测都真打后端
        const hasEndpoint = !!settings.backendEndpoint;
        const backendOk = hasEndpoint ? (await backendGate.check(settings.backendEndpoint)).ok : false;
        const desktopOk = await probeDesktop(settings);
        const channel = SC.resolveChannel({mode: settings.syncChannelMode, hasEndpoint, backendOk, desktopOk});
        const outbox = OB.createOutbox(chrome.storage.local);
        const pending = (await outbox.readAll()).length;
        return {mode: settings.syncChannelMode, hasEndpoint, backendOk, desktopOk, channel, pending, enabled: settings.enabled};
      }
      case 'FLUSH_OUTBOX': {
        const deviceId = await ensureDeviceId();
        return flushOutbox(settings, SC.makeBackendGate(), deviceId);
      }
      default:
        return null;
    }
  })();
  p.then(sendResponse, (e) =>
    sendResponse({ok: false, error: (e && e.message) || String(e), code: e && e.code}),
  );
  return true; // async response
});

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDeviceId();
  const o = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const patch = {};
  for (const k of Object.keys(DEFAULTS)) if (o[k] === undefined) patch[k] = DEFAULTS[k];
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
});

// 快捷键 Alt+Shift+S：保存当前文章页（X 走提取，公众号走桌面递交）
if (typeof chrome.commands !== 'undefined' && chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener((command) => {
    if (command !== 'save-current-article') return;
    Promise.resolve(chrome.tabs.query({active: true, currentWindow: true}))
      .then((tabs) => {
        const tab = tabs && tabs[0];
        const url = (tab && tab.url) || '';
        if (!tab || tab.id == null) return;
        if (/^https?:\/\/(?:www\.)?(?:x|twitter)\.com\//.test(url)) runSave(tab.id);
        else if (/^https:\/\/mp\.weixin\.qq\.com\/s(\/|\?|$)/.test(url)) {
          chrome.tabs.sendMessage(tab.id, {type: 'SAVE_CURRENT'}).catch(() => {});
        }
      })
      .catch(() => {});
  });
}

/* ---------- 测试导出面（不影响运行时） ---------- */
self.__downxBg = {
  DEFAULTS,
  runSave,
  saveWechat,
  runSaveViaWechatBridge,
  flushOutbox,
  resolveSyncChannel,
  runSaveViaBackend,
  runSaveViaDownloads,
  tryAcquireJob,
  releaseJob,
  _setJob: (j) => {
    currentJob = j;
  },
  _reset: () => {
    currentJob = null;
    desktopProbeCache = {at: 0, ok: false};
  },
};
