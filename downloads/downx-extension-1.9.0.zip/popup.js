// popup.js · 弹窗：桌面/后端连接状态 + 当前选路 + 待补推队列（UI_PROBE / FLUSH_OUTBOX 消息）
const $ = (id) => document.getElementById(id);

const CHANNEL_TEXT = {
  backend: '后端直连（同步入库）',
  desktop: '桌面端 DownX',
  download: '浏览器下载目录（兜底）',
  error: '后端不可达（通道锁定为仅后端）',
};

async function probe() {
  let p = null;
  try {
    p = await chrome.runtime.sendMessage({type: 'UI_PROBE'});
  } catch (e) {
    p = null;
  }
  // 桌面端状态沿用 health 消息（在线时带版本）
  let h = null;
  try {
    h = await chrome.runtime.sendMessage({type: 'health'});
  } catch (e) {
    h = null;
  }
  const online = !!(h && h.online);
  $('status').textContent = online
    ? `已连接 DownX${h.data && h.data.version ? ` (${h.data.version})` : ''}`
    : '未连接桌面端（自动模式将走后端或下载目录）';
  $('status').className = online ? 'ok' : 'bad';

  if (p) {
    $('backend').textContent = !p.hasEndpoint
      ? '未配置（打开设置页可自动检测）'
      : p.backendOk ? '已连接' : '不可达';
    $('backend').className = !p.hasEndpoint ? 'muted' : p.backendOk ? 'ok' : 'bad';
    $('channel').textContent =
      (p.mode === 'auto' ? '自动 · ' : p.mode === 'backend' ? '仅后端 · ' : '仅桌面 · ') +
      (CHANNEL_TEXT[p.channel] || p.channel);
    $('channel').className = p.channel === 'error' ? 'bad' : '';
    $('outbox').textContent = p.pending ? `${p.pending} 篇` : '无';
    $('outbox').className = p.pending ? 'bad' : 'muted';
    $('flush').disabled = !p.pending || !p.hasEndpoint;
  } else {
    $('backend').textContent = '状态未知';
    $('channel').textContent = '—';
    $('outbox').textContent = '—';
    $('flush').disabled = true;
  }
}

$('check').onclick = probe;
$('options').onclick = () => chrome.runtime.openOptionsPage();
$('flush').onclick = async () => {
  $('flush').disabled = true;
  try {
    const r = await chrome.runtime.sendMessage({type: 'FLUSH_OUTBOX'});
    if (r && r.pushed) {
      $('outbox').textContent = r.remaining ? `${r.remaining} 篇` : '无';
    }
  } catch (e) {
    /* 探测失败保持现状 */
  }
  probe();
};
probe();

/* ---------- 访问入口（Web / H5 / 下载中心 / APP） ---------- */
// 只读 chrome.storage.local 的 5 个 key，解析口径全部委托 entry-urls.js（与设置页同一份规则）。
// 不做网络探测、不申请 host 权限：开新标签无需权限，而 H5 独立端口那类形态只能由设置页
// 「探测入口地址」回填后在此处生效。

const EU = self.DownXEntryUrls;
// [入口 kind, 按钮 id] —— kind 与存储 key <kind>EntryUrl 一一对应
const ENTRY_KINDS = [
  ['web', 'entryWeb'],
  ['h5', 'entryH5'],
  ['download', 'entryDownload'],
  ['app', 'entryApp'],
];
const ENTRY_DEFAULTS = {
  backendEndpoint: '',
  webEntryUrl: '',
  h5EntryUrl: '',
  downloadEntryUrl: '',
  appEntryUrl: '',
};

function readStorage(keys) {
  return new Promise((res) => chrome.storage.local.get(keys, (s) => res(s || {})));
}

function hostOf(url) {
  try {
    return new URL(url).host;
  } catch (e) {
    return '';
  }
}

async function renderEntries() {
  const s = await readStorage(ENTRY_DEFAULTS);
  const urls = {};
  // blocked = 站内有入口该置灰（API 口现算 / H5 不同源），要不要亮指路行；APP 与此无关
  let blocked = false;
  for (const [kind, id] of ENTRY_KINDS) {
    const url = EU.resolveEntry(kind, s);
    urls[kind] = url;
    const usable = EU.entryUsable(kind, s);
    if (!usable && kind !== 'app') blocked = true;
    const btn = $(id);
    btn.disabled = !usable;
    btn.onclick = () => {
      chrome.tabs.create({url});
      window.close();
    };
  }
  // 主机名只标一处：站内三入口优先取 Web，全算不出时指路设置页
  const host = hostOf(urls.web || urls.h5 || urls.download);
  $('entryHost').textContent = host || '未配置服务地址';
  // 指路分三种：没配置 / 后端是 API 口 / H5 不在同源（这一档 Web 与下载中心都是好的）
  $('entryHintText').textContent = !host ? '未配置服务地址，先到设置页填写后端地址'
    : EU.isWebRootLike(s) ? '此部署的 H5 不在同源 /h5/，需填写 H5 入口地址'
      : '后端地址像是 API 端口，站内入口需先「探测入口地址」并保存';
  $('entryHint').hidden = !blocked;
  $('entrySetup').onclick = () => {
    chrome.runtime.openOptionsPage();
    window.close();
  };
}

renderEntries();

self.__downxPopup = {renderEntries, readStorage, hostOf, ENTRY_KINDS};
