// sync-channel.js · 同步通道层：通道选择 / 后端探活 / xdoc-api 同步契约调用
// 纯逻辑模块（fetch 可注入），background 经 importScripts 使用，node --test 可回归。
// 契约来源：xdoc-api SyncController（POST /api/sync/articles/batch/json、
// POST /api/sync/articles/{id}/media）、ArticleController（GET /api/health）、
// R 信封 {code,message,data}（code=0 成功）。
// 文章 ID 与桌面端 storage.rs article_key 同式：URL 中 article|status 段后的纯数字 → article-{digits}，
// 保证扩展与桌面端同步的数据在同一后端行上收敛（insertOrUpdate 幂等）。
(function (root) {
  'use strict';

  /* ---------- 错误分类 ---------- */
  // SyncError.kind：
  //   'unavailable' 后端不可用（网络错误/超时/HTTP 0/5xx）→ auto 模式允许降级
  //   'auth'        401/403 → 配置错误，不降级
  //   'business'    其余 4xx / 信封 code!=0 → 请求本身有误，不降级
  function SyncError(kind, message, raw) {
    var e = new Error(message);
    e.kind = kind;
    e.raw = raw == null ? '' : String(raw);
    return e;
  }
  function classifyHttpStatus(status) {
    if (status >= 200 && status < 400) return null;
    if (status === 401 || status === 403) return 'auth';
    if (status >= 500 || status === 0) return 'unavailable';
    return 'business';
  }
  function syncErrorFromResponse(status, bodyText) {
    var kind = classifyHttpStatus(status) || 'business';
    var msg =
      kind === 'unavailable'
        ? '后端服务不可用（HTTP ' + status + '）'
        : kind === 'auth'
          ? '后端鉴权失败（HTTP ' + status + '）'
          : '后端拒绝请求（HTTP ' + status + '）';
    return SyncError(kind, msg, bodyText || '');
  }

  /* ---------- 通道选择（纯函数） ---------- */
  // mode: 'auto' | 'backend' | 'desktop'
  // 返回 'backend' | 'desktop' | 'download' | 'error'（error=锁定后端但不可用，按设计不降级）
  function resolveChannel(opts) {
    opts = opts || {};
    var mode =
      opts.mode === 'backend' || opts.mode === 'desktop' ? opts.mode : 'auto';
    var backendUsable = !!opts.hasEndpoint && !!opts.backendOk;
    if (mode === 'backend') return backendUsable ? 'backend' : 'error';
    if (mode === 'desktop') return opts.desktopOk ? 'desktop' : 'download';
    if (opts.hasEndpoint) {
      if (backendUsable) return 'backend';
      return opts.desktopOk ? 'desktop' : 'download';
    }
    return opts.desktopOk ? 'desktop' : 'download';
  }

  /* ---------- 文章 ID（与桌面端 article_key 同式） ---------- */
  function articleKey(url) {
    try {
      var u = new URL(String(url));
      var p = u.pathname.split('/').filter(Boolean);
      for (var i = 0; i < p.length; i++) {
        if (p[i] === 'article' || p[i] === 'status') {
          var id = p[i + 1];
          if (id && /^\d+$/.test(id)) return 'article-' + id;
          return null;
        }
      }
    } catch (e) {
      /* fallthrough */
    }
    return null;
  }

  /* ---------- fetch 超时包装 ---------- */
  function fetchWithTimeout(fetchImpl, url, opts, timeoutMs) {
    var ctrl =
      typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = null;
    var o = Object.assign({}, opts || {});
    if (ctrl) {
      o.signal = ctrl.signal;
      timer = setTimeout(function () {
        ctrl.abort();
      }, timeoutMs);
    }
    return Promise.resolve(fetchImpl(url, o)).finally(function () {
      if (timer) clearTimeout(timer);
    });
  }

  /* ---------- xdoc-api 契约层 ---------- */
  function trimBase(endpoint) {
    return String(endpoint || '').replace(/\/+$/, '');
  }
  // 统一信封解包：HTTP 层错误先分类；code!=0 视为业务错误（不降级）。
  function unwrapR(json) {
    if (!json || typeof json !== 'object' || json.code === undefined)
      throw SyncError('business', '后端响应缺少信封（code）', '');
    if (json.code !== 0)
      throw SyncError(
        'business',
        '后端返回错误：' + (json.message || 'code=' + json.code),
        '',
      );
    return json.data == null ? {} : json.data;
  }
  function requestJson(ctx, method, url, body) {
    var opts = {
      method: method,
      mode: 'cors',
      headers: Object.assign(
        { Accept: 'application/json' },
        ctx.token ? { Authorization: 'Bearer ' + ctx.token } : null,
        body ? { 'Content-Type': 'application/json' } : null,
      ),
    };
    if (body) opts.body = JSON.stringify(body);
    return fetchWithTimeout(ctx.fetch, url, opts, ctx.timeoutMs || 10000).then(
      function (r) {
        if (!r.ok)
          return r.text().then(function (t) {
            throw syncErrorFromResponse(r.status, t);
          });
        return r.json().then(unwrapR);
      },
      function (e) {
        if (e && e.kind) throw e;
        throw SyncError('unavailable', '无法连接后端服务（网络或地址不可达）', (e && e.message) || String(e));
      },
    );
  }

  // 探活：GET /api/health。ok → {ok:true,serverTime,version}；任何失败 → {ok:false}（不抛错）。
  function probeBackend(endpoint, ctx) {
    ctx = ctx || {};
    if (!endpoint) return Promise.resolve({ ok: false });
    return requestJson(
      { fetch: ctx.fetch || (typeof fetch !== 'undefined' ? fetch : null), timeoutMs: ctx.timeoutMs || 2000 },
      'GET',
      trimBase(endpoint) + '/api/health',
      null,
    ).then(
      function (data) {
        return { ok: true, serverTime: Number(data && data.serverTime) || 0, version: (data && data.version) || '' };
      },
      function () {
        return { ok: false };
      },
    );
  }

  // 探活结果缓存（TTL 默认 30s；同端点才复用，换端点立即失效）。
  function makeBackendGate(ttlMs, probeFn) {
    var ttl = ttlMs == null ? 30000 : ttlMs;
    var cache = null; // {endpoint, ok, serverTime, at}
    function check(endpoint, nowMs, ctx) {
      var now = nowMs == null ? Date.now() : nowMs;
      var base = trimBase(endpoint);
      if (!base) return Promise.resolve({ ok: false });
      if (cache && cache.endpoint === base && now - cache.at < ttl)
        return Promise.resolve({ ok: cache.ok, serverTime: cache.serverTime, cached: true });
      var p = probeFn ? probeFn(base, ctx) : probeBackend(base, ctx);
      return Promise.resolve(p).then(function (r) {
        cache = { endpoint: base, ok: !!(r && r.ok), serverTime: (r && r.serverTime) || 0, at: now };
        return { ok: cache.ok, serverTime: cache.serverTime };
      });
    }
    return {
      check: check,
      invalidate: function () {
        cache = null;
      },
      _cache: function () {
        return cache;
      },
    };
  }

  /* ---------- 快照 → ContentBundleDTO ---------- */
  // snapshot（extractor.js 产出）：
  //   {title, author_name, author_handle, publish_time, original_url, blocks[], media[], warnings[], fetched_at}
  //   media[i] = {url, media_type:'image'|'video', description, poster, width, height, duration, streamOnly}
  // mediaMeta（上传后回填的终态，可选）：[{status:'ok'|'failed'|'skipped', error}]
  function buildBundle(snapshot, opts) {
    opts = opts || {};
    snapshot = snapshot || {};
    var key = articleKey(snapshot.original_url);
    if (!key) throw SyncError('business', '无法从 URL 解析文章 ID：' + snapshot.original_url, '');
    var media = Array.isArray(snapshot.media) ? snapshot.media : [];
    var blocks = Array.isArray(snapshot.blocks) ? snapshot.blocks : [];
    var warnings = (Array.isArray(snapshot.warnings) ? snapshot.warnings : []).slice();
    var mediaMeta = opts.mediaMeta || null;

    var imageCount = 0, videoCount = 0;
    for (var i = 0; i < media.length; i++) {
      if (media[i].media_type === 'video') videoCount++;
      else imageCount++;
    }
    // 正文失败媒体（上传/下载失败）折算为 warning，integrity 降级为 partial
    var failedMedia = [];
    if (mediaMeta) {
      for (var j = 0; j < mediaMeta.length; j++) {
        if (mediaMeta[j] && mediaMeta[j].status === 'failed')
          failedMedia.push('媒体 #' + j + ' 保存失败：' + (mediaMeta[j].error || '未知原因'));
      }
    }
    var allWarnings = warnings.concat(failedMedia);
    var wordCount = 0;
    for (var k = 0; k < blocks.length; k++) {
      if (blocks[k] && blocks[k].text) wordCount += String(blocks[k].text).trim().length;
    }
    return {
      id: key,
      title: snapshot.title == null ? '' : String(snapshot.title),
      authorName: snapshot.author_name == null ? '' : String(snapshot.author_name),
      authorHandle: snapshot.author_handle == null ? '' : String(snapshot.author_handle),
      originalUrl: snapshot.original_url == null ? '' : String(snapshot.original_url),
      sourceUrl: snapshot.original_url == null ? '' : String(snapshot.original_url),
      publishTime: snapshot.publish_time || '',
      fetchedAt: snapshot.fetched_at || new Date().toISOString(),
      integrityStatus: allWarnings.length ? 'partial' : 'complete',
      imageCount: imageCount,
      videoCount: videoCount,
      wordCount: wordCount,
      blocks: blocks,
      warnings: allWarnings,
      media: media.map(function (m) {
        return {
          url: m.url == null ? '' : String(m.url),
          mediaType: m.media_type || 'image',
          description: m.description || null,
          poster: m.poster || null,
          width: m.width > 0 ? m.width : null,
          height: m.height > 0 ? m.height : null,
          duration: m.duration > 0 ? m.duration : null,
        };
      }),
      source: 'browser-extension',
      sourceTaskId: opts.sourceTaskId || '',
    };
  }

  /* ---------- 推送与媒体上传 ---------- */
  // 单 bundle 推送：POST /api/sync/articles/batch/json?device=&clientVersion=
  // items[0].status !== 'success' 视为业务失败（携带 reason）。
  function pushBundles(endpoint, bundle, device, clientVersion, ctx) {
    ctx = ctx || {};
    var qs = '?';
    if (device) qs += 'device=' + encodeURIComponent(device) + '&';
    qs += 'clientVersion=' + encodeURIComponent(clientVersion || 'browser-extension');
    var url = trimBase(endpoint) + '/api/sync/articles/batch/json' + qs;
    return requestJson(
      { fetch: ctx.fetch || (typeof fetch !== 'undefined' ? fetch : null), timeoutMs: ctx.timeoutMs || 30000, token: ctx.token },
      'POST',
      url,
      [bundle],
    ).then(function (data) {
      var item = data && data.items && data.items[0];
      if (!item || item.status !== 'success')
        throw SyncError('business', '文章同步被拒绝：' + ((item && item.reason) || '未知原因'), '');
      return { ok: true, batchId: data.batchId || '', articleId: bundle.id };
    });
  }

  // 媒体上传：multipart POST /api/sync/articles/{id}/media
  // 服务端落 uploadDir/{articleId}/{uuid}/{sortNo}_{filename} 并按 (article_id, sort_no) 回填 Media.url。
  // 返回 {ok:true, url}；meta 携带 mediaType/originalUrl/description/width/height/duration/device。
  function uploadArticleMedia(endpoint, articleId, uuid, sortNo, blob, meta, ctx) {
    ctx = ctx || {};
    meta = meta || {};
    var url =
      trimBase(endpoint) +
      '/api/sync/articles/' +
      encodeURIComponent(articleId) +
      '/media';
    var fd = new FormData();
    fd.append('file', blob, meta.filename || 'media.bin');
    fd.append('sortNo', String(sortNo));
    fd.append('uuid', String(uuid));
    if (meta.mediaType) fd.append('mediaType', meta.mediaType);
    if (meta.filename) fd.append('filename', meta.filename);
    if (meta.originalUrl) fd.append('originalUrl', meta.originalUrl);
    if (meta.description) fd.append('description', meta.description);
    if (meta.width > 0) fd.append('width', String(meta.width));
    if (meta.height > 0) fd.append('height', String(meta.height));
    if (meta.duration > 0) fd.append('duration', String(meta.duration));
    if (meta.device) fd.append('device', meta.device);
    return fetchWithTimeout(
      ctx.fetch || (typeof fetch !== 'undefined' ? fetch : null),
      url,
      {
        method: 'POST',
        mode: 'cors',
        headers: Object.assign(
          { Accept: 'application/json' },
          ctx.token ? { Authorization: 'Bearer ' + ctx.token } : null,
        ),
        body: fd,
      },
      ctx.timeoutMs || 120000,
    ).then(function (r) {
      if (!r.ok)
        return r.text().then(function (t) {
          throw syncErrorFromResponse(r.status, t);
        });
      return r.json().then(unwrapR);
    }).then(function (data) {
      if (!data || !data.url) throw SyncError('business', '后端未返回媒体 URL', '');
      return { ok: true, url: data.url };
    });
  }

  // 墓碑 id 全集（上限内）：GET /api/sync/tombstones?since=0
  // outbox 冲刷前感知跨端删除——已删文章若照常补推，会借行级复活守卫
  // （fetched_at >= deleted_at）把文章全端"凭空复活"。拉取失败返回 null，
  // 调用方按「未知」处理、维持旧补推行为（fail-open，不因检查失败丢文章）。
  function fetchTombstoneIds(endpoint, ctx) {
    ctx = ctx || {};
    var url = trimBase(endpoint) + '/api/sync/tombstones?since=0';
    return requestJson(
      { fetch: ctx.fetch || (typeof fetch !== 'undefined' ? fetch : null), timeoutMs: ctx.timeoutMs || 10000, token: ctx.token },
      'GET',
      url,
      null,
    ).then(function (data) {
      var entries = (data && data.entries) || [];
      var ids = {};
      for (var i = 0; i < entries.length; i++) {
        if (entries[i] && entries[i].id) ids[entries[i].id] = true;
      }
      return ids;
    }).catch(function () {
      return null;
    });
  }

  var api = {
    SyncError: SyncError,
    classifyHttpStatus: classifyHttpStatus,
    syncErrorFromResponse: syncErrorFromResponse,
    resolveChannel: resolveChannel,
    articleKey: articleKey,
    fetchWithTimeout: fetchWithTimeout,
    trimBase: trimBase,
    unwrapR: unwrapR,
    probeBackend: probeBackend,
    makeBackendGate: makeBackendGate,
    buildBundle: buildBundle,
    pushBundles: pushBundles,
    uploadArticleMedia: uploadArticleMedia,
    fetchTombstoneIds: fetchTombstoneIds,
  };
  root.DownXSyncChannel = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
