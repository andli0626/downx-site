// extractor.js · content script：X 文章/帖子 DOM 提取（移植桌面端 CDP 注入脚本）
// 来源：xdoc-desk/src-tauri/scripts/content-target.js（downxContentTarget 定位逻辑）
//      + extract-article.js（块遍历/媒体采集/普通帖降级），语义保持一致。
// 扩展侧增强：媒体补充 width/height/duration；blob:/m3u8 视频标记 streamOnly
// （后台无法直接 fetch，仅同步元数据，由桌面端/Web 端回源补齐）。
(function (root) {
  'use strict';

  // —— 定位目标帖（与桌面 downxContentTarget 同式）：匹配 permalink 的 article，绝不取线程第一条 ——
  function contentTarget(doc, loc) {
    doc = doc || document;
    loc = loc || location;
    const status = loc.pathname.match(/^\/[A-Za-z0-9_]+\/status\/(\d+)\/?$/);
    const owns = (container, node) => {
      if (node.closest('article') !== container) return false;
      for (let parent = node.parentElement; parent && parent !== container; parent = parent.parentElement) {
        if (parent.matches('[role="link"], [data-testid="quoteTweet"]')) return false;
      }
      return true;
    };
    const post = status && [...doc.querySelectorAll('article')].find(tweet =>
      [...tweet.querySelectorAll('a[href]')].some(a => {
        if (!owns(tweet, a) || !a.querySelector('time')) return false;
        return new URL(a.href, loc.href).pathname.match(/^\/[A-Za-z0-9_]+\/status\/(\d+)\/?$/)?.[1] === status[1];
      })
    );
    // 阅读视图优先：原生带 <strong>/<em>/<a>、h2/h3、ul/li、blockquote 与
    // white-space: pre-wrap，和原文排版一一对应；取不到再回退编辑器视图。
    // 未登录 SSR 用 [data-article-body-html]（更贴近原文的内层根）；登录态主要靠
    // .x-article-body。用 querySelectorAll + find，避免引用推的同类节点抢先命中。
    const inPost = node => !post || node.closest('article') === post || !node.closest('article');
    const readView = [...doc.querySelectorAll('[data-article-body-html]')].find(inPost)
      || [...doc.querySelectorAll('.x-article-body')].find(inPost);
    const rich = readView || [...doc.querySelectorAll('[data-testid="twitterArticleRichTextView"], [data-testid="longformRichTextComponent"], [data-testid="twitterArticleReadView"] [class*="DraftEditor-root"]')].find(node => {
      const tweet = node.closest('article[data-testid="tweet"]');
      // permalink article 在部分布局里包在 role=link 容器内；该容器不是引用推，
      // 一旦其宿主 article 与 permalink 帖匹配，直接接受其富文本节点。
      return !tweet || tweet === post;
    });
    let link = null;
    if (post && !rich) {
      const anchor = [...post.querySelectorAll('a[href]')].find(a => {
        const u = new URL(a.href, loc.href);
        return owns(post, a) && ['x.com', 'twitter.com'].includes(u.hostname)
          && /^\/(?:i|[A-Za-z0-9_]+)\/article\/\d+\/?$/.test(u.pathname);
      });
      link = anchor?.href || null;
    }
    const text = post && [...post.querySelectorAll('[data-testid="tweetText"], [data-testid^="tweetText_"]')].find(node => owns(post, node));
    const media = post ? [...post.querySelectorAll('[data-testid="tweetPhoto"] img, [data-testid*="card.layoutLarge.media"] img, video')].filter(node => owns(post, node)) : [];
    const preview = post?.querySelector('[data-testid="tweetArticle"], [data-testid="articlePreview"]');
    return {root: rich || post || null, rich: !!rich, post, text, media, link,
      articlePending: !rich && (!!link || (preview && owns(post, preview))),
      owns: node => !!post && owns(post, node)};
  }

  // blob:/HLS 视频源无法在后台直接下载
  function isStreamOnlyUrl(src) {
    if (!src) return false;
    if (src.startsWith('blob:')) return true;
    return /\.m3u8(\?|$)/i.test(src);
  }

  // 归档保真：pbs.twimg.com/media 缩略图参数 small/medium 归一为 large（orig/无 name 不动）
  function normalizeImageSrc(src) {
    if (!src || !src.includes('pbs.twimg.com/media/')) return src;
    const m = src.match(/^([^?]*)(\?[^?]*)?$/);
    if (!m || !m[2]) return src;
    const params = new URLSearchParams(m[2]);
    const name = params.get('name');
    if (name !== 'small' && name !== 'medium') return src;
    params.set('name', 'large');
    return m[1] + '?' + params.toString();
  }

  // —— 主提取：成功 {ok:true, snapshot}；失败 {ok:false, error}（不抛异常） ——
  function extractSnapshot(doc, loc, options) {
    doc = doc || document;
    loc = loc || location;
    const preferLargeImage = !options || options.preferLargeImage !== false;
    try {
      const target = contentTarget(doc, loc);
      const root = target.root;
      if (!root) return {ok: false, error: '未找到 X 帖子内容，页面尚未加载'};
      if (target.articlePending) return {ok: false, error: '长文正文尚未加载，不能只保存预览'};

      const titleNode = doc.querySelector('[data-testid="twitterArticleTitle"], [data-testid="twitter-article-title"]');
      let title = titleNode?.textContent?.trim() || doc.querySelector('meta[property="og:title"]')?.content || doc.title.replace(/\s*[/|]\s*X$/, '');
      const scope = root.closest('article') || doc.querySelector('main') || doc;
      const main = root.closest('main') || scope;
      const authorNode = scope.querySelector('[data-testid="User-Name"]') || main.querySelector('[data-testid="User-Name"]');
      const handleMatch = authorNode?.textContent.match(/@([A-Za-z0-9_]+)/);
      const pathHandle = loc.pathname.split('/')[1];
      const handle = handleMatch?.[1] || (pathHandle !== 'i' ? pathHandle : '');
      const author = authorNode?.querySelector('a span')?.textContent || handle;

      const blocks = [], media = [], seen = new Set();
      // 格式保真：class/style 承载加粗、斜体与 pre-wrap，data-* 标记编辑器块类型。
      // 过去只留 href/colspan/rowspan/start，详情会丢掉全部强调与段内换行。
      const KEEP_ATTRS = new Set(['href','colspan','rowspan','start','src','alt','width','height',
        'poster','controls','preload','type','title','class','style']);
      const addMedia = (el, type) => {
        let src = type === 'video' ? (el.currentSrc || el.src || el.querySelector('source')?.src || '') : (el.currentSrc || el.src || '');
        if (type === 'image' && preferLargeImage) src = normalizeImageSrc(src);
        const poster = type === 'video' ? (el.poster || null) : null;
        const key = type + ':' + (src || poster); if (seen.has(key)) return; seen.add(key);
        if (type === 'image' && (!src.includes('pbs.twimg.com') && !src.startsWith('https://'))) return;
        const i = media.length;
        media.push({
          url: src, media_type: type, description: el.alt || null, poster,
          width: (type === 'image' ? el.naturalWidth : el.videoWidth) || 0,
          height: (type === 'image' ? el.naturalHeight : el.videoHeight) || 0,
          duration: type === 'video' && isFinite(el.duration) && el.duration > 0 ? el.duration : 0,
          streamOnly: type === 'video' && isStreamOnlyUrl(src),
        });
        blocks.push({kind: type, media_index: i, text: '', html: ''});
      };
      const walk = el => {
        if (el.nodeType === 3) { const text = el.textContent.trim(); if (text) { const p = doc.createElement('p'); p.textContent = text; blocks.push({kind: 'paragraph', text, html: p.outerHTML}); } return; }
        if (el.nodeType !== 1) return;
        const tag = el.tagName.toLowerCase();
        if (['script', 'style', 'button', 'svg', 'nav'].includes(tag)) return;
        if (tag === 'video') { addMedia(el, 'video'); return; }
        if (tag === 'img') { addMedia(el, 'image'); return; }
        const mediaInside = el.querySelector('img,video');
        const text = (el.innerText || el.textContent || '').trim();
        let kind = /^h[1-6]$/.test(tag) ? 'heading' : ({p: 'paragraph', blockquote: 'quote', pre: 'code', ul: 'list', ol: 'ordered_list', table: 'table'})[tag];
        if (!kind && el.matches('[data-block="true"]') && !el.querySelector('[data-block="true"]')) kind = 'paragraph';
        if (kind && text && !mediaInside) {
          const clone = el.cloneNode(true); clone.querySelectorAll('script,style,button,svg').forEach(n => n.remove());
          clone.querySelectorAll('*').forEach(n => { for (const a of [...n.attributes]) if (!KEEP_ATTRS.has(a.name)) n.removeAttribute(a.name); });
          const html = kind === 'paragraph' && !['p', 'blockquote'].includes(tag) ? `<p>${clone.innerHTML}</p>` : clone.outerHTML;
          blocks.push({kind, text, html, level: kind === 'heading' ? Number(tag[1]) : 0, rows: tag === 'table' ? [...el.querySelectorAll('tr')].map(tr => [...tr.querySelectorAll('th,td')].map(td => td.textContent.trim())) : []});
          return;
        }
        if (!el.children.length && text) { blocks.push({kind: 'paragraph', text, html: `<p>${el.innerHTML}</p>`}); return; }
        [...el.childNodes].forEach(walk);
      };

      // 封面可能在富文本 root 之外；仅收录于 Article 阅读视图内、位于正文之前的媒体
      const articleView = root.closest('[data-testid="twitterArticleReadView"]');
      if (articleView) for (const img of articleView.querySelectorAll('img')) { if (root.contains(img)) continue; if (img.src.includes('pbs.twimg.com/media/') && (img.compareDocumentPosition(root) & Node.DOCUMENT_POSITION_FOLLOWING)) addMedia(img, 'image'); }

      if (target.rich) walk(root);
      else {
        if (target.text) {
          const clone = target.text.cloneNode(true);
          clone.querySelectorAll('img').forEach(img => img.replaceWith(doc.createTextNode(img.alt || '')));
          clone.querySelectorAll('br').forEach(br => br.replaceWith(doc.createTextNode('\n')));
          let text = (clone.textContent || '').trim();
          const description = doc.querySelector('meta[property="og:description"]')?.content?.trim();
          if (description && /^https?:\/\/(?:t\.co|x\.com)\//.test(text) && description !== title) text = description;
          if (text) {
            const p = doc.createElement('p'); p.textContent = text;
            blocks.push({kind: 'paragraph', text, html: p.outerHTML});
          }
        }
        for (const el of target.media) addMedia(el, el.tagName === 'VIDEO' ? 'video' : 'image');
        title = blocks.find(b => b.text)?.text.replace(/\s+/g, ' ').slice(0, 80) || `@${handle} 的媒体帖`;
      }

      const warnings = [];
      if (!blocks.some(b => b.text) && !media.length) return {ok: false, error: 'X 帖子正文为空'};
      if (root.querySelector('[aria-busy="true"],[role="progressbar"]')) warnings.push('正文仍有加载中的内容');
      if (target.rich && !titleNode) warnings.push('未找到官方文章标题节点，标题使用页面元信息');
      if (!handle) warnings.push('作者信息未完全加载');
      for (const m of media) if (m.streamOnly) warnings.push('视频为流媒体源（blob/HLS），扩展端仅记录元数据，文件可用桌面端或 Web 端回源补齐');

      return {
        ok: true,
        snapshot: {
          title, author_name: author, author_handle: handle,
          publish_time: (scope.querySelector('time') || main.querySelector('time'))?.dateTime || null,
          original_url: loc.href, blocks, media, warnings,
          source_block_count: blocks.length,
          fetched_at: new Date().toISOString(),
        },
      };
    } catch (e) {
      return {ok: false, error: (e && e.message) || String(e)};
    }
  }

  var api = {extractSnapshot: extractSnapshot, contentTarget: contentTarget, isStreamOnlyUrl: isStreamOnlyUrl, normalizeImageSrc: normalizeImageSrc};
  root.DownXExtractor = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;

  // background → tab 的请求应答（真实 content script 环境；jsdom/node 导入期不注册）
  // EXTRACT_REQUEST → {ok,snapshot|error}；BUILD_MD{snapshot,mediaUrls} → {markdown}
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg || !msg.type) return;
      if (msg.type === 'EXTRACT_REQUEST') {
        sendResponse(extractSnapshot(undefined, undefined, msg.options));
        return;
      }
      if (msg.type === 'BUILD_MD') {
        try {
          sendResponse({ok: true, markdown: root.DownXMdBuilder.buildMarkdown(msg.snapshot || {}, {mediaUrls: msg.mediaUrls || []})});
        } catch (e) {
          sendResponse({ok: false, error: (e && e.message) || String(e)});
        }
      }
    });
  }
})(typeof self !== 'undefined' ? self : globalThis);
