// md-builder.js · content script：blocks → Markdown（frontmatter + 正文 + 媒体引用注入）
// mediaUrls[i] 为第 i 个媒体的最终引用 URL：
//   backend 通道 = /api/media/...（上传回填）；download 通道 = media/{本地文件名}；desktop 通道 = 原始 URL。
// mediaFilename：生成 {sortNo}_{basename} 媒体文件名，与后端 uploadDir 命名规则同构。
(function (root) {
  'use strict';

  // 从媒体 URL 推导本地文件名：取 pathname 末段；pbs.twimg.com/media/abc?format=jpg 用 format 参数补扩展名。
  function mediaFilename(m, index) {
    m = m || {};
    let name = '';
    let ext = '';
    try {
      const u = new URL(m.url);
      const seg = u.pathname.split('/').filter(Boolean);
      name = seg[seg.length - 1] || '';
      ext = (u.searchParams.get('format') || '').toLowerCase();
    } catch (e) { /* blob: 等非法 URL 走兜底 */ }
    if (!/\.[a-z0-9]{2,5}$/i.test(name)) {
      name += ext ? '.' + ext : (m.media_type === 'video' ? '.mp4' : '.jpg');
    }
    name = name.replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 120) || ('media_' + index);
    return index + '_' + name;
  }

  function tableToMarkdown(rows) {
    if (!rows || !rows.length) return '';
    const head = rows[0].map(c => (c || '').replace(/\|/g, '\\|') || ' ');
    const out = ['| ' + head.join(' | ') + ' |', '|' + head.map(() => ' --- ').join('|') + '|'];
    for (let r = 1; r < rows.length; r++) {
      const cells = rows[r].map(c => (c || '').replace(/\|/g, '\\|'));
      out.push('| ' + cells.join(' | ') + ' |');
    }
    return out.join('\n');
  }

  // text 多行时逐行加前缀（引用/列表）
  function prefixLines(text, prefix) {
    return String(text || '')
      .split('\n')
      .map(l => prefix + l)
      .join('\n');
  }

  // 把采集到的行内 HTML 转成语义 Markdown（加粗/斜体/链接/换行/行内图片）。
  // 过去 renderBlock 只用 b.text，导致详情 Markdown 丢掉全部强调与链接。
  function inlineMd(html) {
    return String(html || '')
      .replace(/<a\b[^>]*href\s*=\s*["']([^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi,
        (m, href, inner) => '[' + inlineMd(inner) + '](' + href + ')')
      .replace(/<img\b[^>]*src\s*=\s*["']([^"']*)["'][^>]*>/gi, (m, src) => {
        const alt = (m.match(/alt\s*=\s*["']([^"']*)["']/i) || [])[1] || '';
        return '![' + alt + '](' + src + ')';
      })
      .replace(/<\/?(?:b|strong)\b[^>]*>/gi, '**')
      .replace(/<\/?(?:i|em)\b[^>]*>/gi, '*')
      .replace(/<\/?code\b[^>]*>/gi, '`')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
  }

  function isPlaceholderCaption(s) {
    return !s || /^(图像|图片|image|图片描述|视频封面|媒体\d+)$/i.test(String(s).trim());
  }

  // 只看 host：公众号链接参数里出现 x.com 不能被误判成 X 文章。
  function isXArticleUrl(u) {
    return /^(?:https?:\/\/)?(?:[a-z0-9-]+\.)*(?:x\.com|twitter\.com)(?:\/|$)/i
      .test(String(u || '').trim());
  }

  function renderBlock(b, media, mediaUrls) {
    const kind = b.kind;
    if (kind === 'image' || kind === 'video') {
      const i = b.media_index;
      const m = (media && media[i]) || {};
      const url = (mediaUrls && mediaUrls[i]) || m.url || '';
      const desc = (m.description || '').replace(/[\[\]]/g, '') || ('媒体' + (i + 1));
      if (!url) return '';
      return kind === 'image' ? `![${desc}](${url})` : `[视频：${desc}](${url})`;
    }
    if (kind === 'table') return tableToMarkdown(b.rows); // 表格内容在 rows，text 可能为空
    const rich = String(b.html || '');
    const hasInline = /<(b|strong|em|i|a|br|li|img)\b/i.test(rich);
    const text = (hasInline ? inlineMd(rich) : String(b.text || '')).trim();
    if (!text) return '';
    switch (kind) {
      case 'heading': {
        let level = Math.min(Math.max(Number(b.level) || 1, 1), 6);
        // X 编辑器 header-one/two 在阅读视图是 h2/h3，Markdown 层级同步 +1。
        if (/longform-header/.test(rich)) level = Math.min(level + 1, 6);
        return '#'.repeat(level) + ' ' + text.replace(/^#+\s*/, '');
      }
      case 'quote': return prefixLines(text, '> ');
      case 'code': return '```\n' + text + '\n```';
      case 'list': {
        const lis = [...rich.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)].map(m => inlineMd(m[1]).trim());
        return lis.length ? lis.map(x => '- ' + x).join('\n') : prefixLines(text, '- ');
      }
      case 'ordered_list': {
        const lis = [...rich.matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)].map(m => inlineMd(m[1]).trim());
        return lis.length ? lis.map((x, i) => (i + 1) + '. ' + x).join('\n') : prefixLines(text, '1. ');
      }
      case 'table': return tableToMarkdown(b.rows);
      default: return text; // paragraph
    }
  }

  function escAttr(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderMediaHtml(m, url, isX) {
    const alt = escAttr(m.description || (m.media_type === 'video' ? '视频' : '图像'));
    if (!url) return '';
    // 只对 X 文章去掉「图像」这类占位说明；公众号的 figcaption 是正文的一部分。
    const caption = isX && isPlaceholderCaption(m.description) ? '' : `<figcaption>${alt}</figcaption>`;
    if (m.media_type === 'video') {
      const poster = m.poster ? ` poster="${escAttr(m.poster)}"` : '';
      return `<figure><video controls preload="metadata" src="${escAttr(url)}"${poster}></video>${caption}</figure>`;
    }
    return `<figure><img src="${escAttr(url)}" alt="${alt}" loading="lazy">${caption}</figure>`;
  }

  // snapshot → HTML 正文（对齐桌面端 render_content 的 html 输出）。
  // 前端文章详情默认展示 HTML 页签，扩展必须回填 html，否则正文区空白。
  function buildHtml(snapshot, opts) {
    snapshot = snapshot || {};
    opts = opts || {};
    const media = Array.isArray(snapshot.media) ? snapshot.media : [];
    const mediaUrls = opts.mediaUrls || [];
    const isX = isXArticleUrl(snapshot.original_url);
    const out = [];
    for (const b of Array.isArray(snapshot.blocks) ? snapshot.blocks : []) {
      if (b.kind === 'image' || b.kind === 'video') {
        const i = b.media_index;
        const m = media[i] || {};
        const url = mediaUrls[i] || m.url || '';
        const h = renderMediaHtml(m, url, isX);
        if (h) out.push(h);
        continue;
      }
      const text = String(b.text || '').trim();
      if (!text && b.kind !== 'table') continue;
      // 文本块 html 由 extractor 生成（已剥离危险属性）；缺失时用纯文本兜底。
      out.push(b.html || `<p>${escAttr(text)}</p>`);
    }
    return out.join('\n');
  }

  function frontmatter(snapshot) {
    const lines = ['---'];
    if (snapshot.title) lines.push('title: ' + String(snapshot.title).replace(/\n/g, ' '));
    if (snapshot.author_name) lines.push('author: ' + String(snapshot.author_name).replace(/\n/g, ' '));
    if (snapshot.author_handle) lines.push('handle: ' + snapshot.author_handle.replace(/^@/, ''));
    if (snapshot.publish_time) lines.push('publish_time: ' + snapshot.publish_time);
    if (snapshot.original_url) lines.push('url: ' + snapshot.original_url);
    if (snapshot.fetched_at) lines.push('fetched_at: ' + snapshot.fetched_at);
    lines.push('---');
    return lines.join('\n');
  }

  // snapshot（extractor 产物）→ markdown 文本；mediaUrls 可选（缺省回退原始 URL）
  function buildMarkdown(snapshot, opts) {
    snapshot = snapshot || {};
    opts = opts || {};
    const media = Array.isArray(snapshot.media) ? snapshot.media : [];
    const mediaUrls = opts.mediaUrls || [];
    const body = (Array.isArray(snapshot.blocks) ? snapshot.blocks : [])
      .map(b => renderBlock(b, media, mediaUrls))
      .filter(s => s !== '')
      .join('\n\n');
    return frontmatter(snapshot) + '\n\n' + body + '\n';
  }

  var api = {buildMarkdown: buildMarkdown, buildHtml: buildHtml, mediaFilename: mediaFilename, renderBlock: renderBlock, frontmatter: frontmatter};
  root.DownXMdBuilder = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
