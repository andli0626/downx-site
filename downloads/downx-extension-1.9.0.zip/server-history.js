// server-history.js · 服务器地址历史纯逻辑（对标 Android ServerHistoryLogic）
// 条目可为裸 url 字符串（后端通道）或 {url, token} 成对（桌面通道），统一按归一化 url 去重。
(function (root) {
  'use strict';

  var HISTORY_MAX = 10;

  function normalizeUrl(raw) {
    if (typeof raw !== 'string') return '';
    return raw.trim().replace(/\/+$/, '');
  }

  function entryUrl(entry, getUrl) {
    var u = entry && getUrl ? getUrl(entry) : entry;
    return normalizeUrl(u);
  }

  // 入档前归一化：字符串直接归一；对象条目归一其 url 字段（其余字段如 token 原样保留）
  function canonicalEntry(entry, getUrl) {
    var url = entryUrl(entry, getUrl);
    if (typeof entry === 'string') return url;
    var copy = Object.assign({}, entry);
    copy.url = url;
    return copy;
  }

  // 去重置顶 + 上限裁尾；空地址不入档，返回新数组
  function addHistory(list, entry, getUrl) {
    var arr = Array.isArray(list) ? list : [];
    var url = entryUrl(entry, getUrl);
    if (!url) return arr.slice();
    var kept = arr.filter(function (e) { return entryUrl(e, getUrl) !== url; });
    return [canonicalEntry(entry, getUrl)].concat(kept).slice(0, HISTORY_MAX);
  }

  function removeHistory(list, url, getUrl) {
    var arr = Array.isArray(list) ? list : [];
    var target = normalizeUrl(url);
    return arr.filter(function (e) { return entryUrl(e, getUrl) !== target; });
  }

  function hasHistory(list, url, getUrl) {
    var arr = Array.isArray(list) ? list : [];
    var target = normalizeUrl(url);
    if (!target) return false;
    return arr.some(function (e) { return entryUrl(e, getUrl) === target; });
  }

  var api = {
    HISTORY_MAX: HISTORY_MAX,
    normalizeUrl: normalizeUrl,
    addHistory: addHistory,
    removeHistory: removeHistory,
    hasHistory: hasHistory,
  };
  root.DownXServerHistory = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
