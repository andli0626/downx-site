// entry-urls.js · 页面入口地址纯逻辑（设置页与弹窗共用，避免两处派生规则漂移）
// 口径来源：docs/01-产品文档/功能描述/浏览器扩展端/02-设置页.md §页面入口。
(function (root) {
  'use strict';

  // Android 蒲公英分发短链，与桌面端 settings-page.js 的 APP_ANDROID_URL 同口径。
  var APP_ANDROID_URL = 'https://www.pgyer.com/xread-android';

  // 服务根地址归一：http(s)://host[:port]，不含 /api 与尾斜杠。非法返回 null，空返回 ''。
  function normalizeEndpoint(raw) {
    var v = String(raw || '').trim().replace(/\/+$/, '');
    if (!v) return '';
    try {
      var u = new URL(v);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
      return u.origin;
    } catch (e) {
      return null;
    }
  }

  // 入口清洗：仅校验合法性 + 去首尾空白，不改写内容。
  // 入口可能是子路径部署（如 /h5/），尾斜杠是路由语义的一部分，与后端地址不同，不能剥除。
  function cleanEntryUrl(raw) {
    var v = String(raw || '').trim();
    if (!v) return '';
    try {
      var u = new URL(v);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
      return v;
    } catch (e) {
      return '';
    }
  }

  /**
   * 解析入口最终地址：填写值优先，留空按占位规则现算
   * （web ← 后端地址、h5 ← web + /h5/、download ← web + /download、app ← 蒲公英短链）。
   *
   * @param {string} kind 'web' | 'h5' | 'download' | 'app'
   * @param {object} values {webEntryUrl, h5EntryUrl, downloadEntryUrl, appEntryUrl, backendEndpoint}
   * @returns {string} 可打开的 URL；算不出为空串
   */
  function resolveEntry(kind, values) {
    var v = values || {};
    if (kind === 'app') return cleanEntryUrl(v.appEntryUrl) || APP_ANDROID_URL;
    var direct = cleanEntryUrl(
      kind === 'web' ? v.webEntryUrl : kind === 'h5' ? v.h5EntryUrl : v.downloadEntryUrl,
    );
    if (direct) return direct;
    var web = webBase(v);
    if (!web) return '';
    return kind === 'web' ? web : web + (kind === 'h5' ? '/h5/' : '/download');
  }

  // 站内入口的派生基准：显式 Web 入口优先，其次后端地址；剥尾斜杠避免拼出 //h5/。
  function webBase(values) {
    var v = values || {};
    return (cleanEntryUrl(v.webEntryUrl) || normalizeEndpoint(v.backendEndpoint) || '').replace(/\/+$/, '');
  }

  function portOf(url) {
    try {
      return new URL(url).port;
    } catch (e) {
      return null;
    }
  }

  // 已知能直出页面的端口：本机 docker 网关 1100、NAS Web 前端 7788（实测 Web 与 /download 都对）。
  // API 口（NAS 6688、本机 16655）只服务后端，留空现算会撞后端引导页与 Whitelabel 错误页；
  // 不带端口（80/443 反代）视为可出页面。设置页的探测候选端口与此同源。
  var WEB_ROOT_PORTS = ['1100', '7788'];

  // 已知会把同源 /h5/ 反代到 H5 前端的端口：只有本机 docker 网关 1100（实测 → /h5/library、「X-Read H5」）。
  // NAS 的 PC 前端（7788）与 H5 前端（7790）是两个独立容器，:7788/h5/ 掉进 SPA 回落、打开的是 Web 端，
  // 所以 NAS 的 H5 入口必须在设置页显式填 :7790/h5/。设置页探测与 xdox-web 顶栏的 H5 按钮同此局限。
  var H5_PROXIED_PORTS = ['1100'];

  /**
   * 后端地址是否「像个 Web 根」——决定留空现算出来的站内入口能不能真打开页面。
   * 显式填写的 webEntryUrl 一律放行（由用户负责），只有从后端地址派生时才看端口。
   */
  function isWebRootLike(values) {
    var v = values || {};
    if (cleanEntryUrl(v.webEntryUrl)) return true;
    var web = normalizeEndpoint(v.backendEndpoint);
    if (!web) return false;
    var port = portOf(web);
    return port === null ? false : !port || WEB_ROOT_PORTS.indexOf(port) >= 0;
  }

  // 同源 /h5/ 派生是否可信：基准端口在反代表内，或根本没带端口（交给站点根的反代）。
  function isH5Proxied(values) {
    var port = portOf(webBase(values));
    return port === null ? false : !port || H5_PROXIED_PORTS.indexOf(port) >= 0;
  }

  /**
   * 入口可点性：URL 算得出，且不是「API 端口现算出来的站内链接」或「不反代 /h5/ 的端口现算的 H5」。
   * APP 与后端无关恒为真；本入口显式填写即由用户负责；留空现算才要求 isWebRootLike。
   */
  function entryUsable(kind, values) {
    var v = values || {};
    if (!resolveEntry(kind, v)) return false;
    if (kind === 'app') return true;
    if (cleanEntryUrl(v[kind + 'EntryUrl'])) return true;
    if (!isWebRootLike(v)) return false;
    return kind === 'h5' ? isH5Proxied(v) : true;
  }

  var api = {
    APP_ANDROID_URL: APP_ANDROID_URL,
    WEB_ROOT_PORTS: WEB_ROOT_PORTS,
    H5_PROXIED_PORTS: H5_PROXIED_PORTS,
    normalizeEndpoint: normalizeEndpoint,
    cleanEntryUrl: cleanEntryUrl,
    resolveEntry: resolveEntry,
    isWebRootLike: isWebRootLike,
    isH5Proxied: isH5Proxied,
    entryUsable: entryUsable,
  };
  root.DownXEntryUrls = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
